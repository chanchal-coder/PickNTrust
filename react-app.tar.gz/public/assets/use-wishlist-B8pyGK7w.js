import{d as s}from"./index-Cb8n_C7G.js";function t(){return s()}export{t as u};
