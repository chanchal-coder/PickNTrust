import{r as a,j as t}from"./vendor-D18aKuk9.js";function g({page:s}={}){const[e,c]=a.useState(null),[u,m]=a.useState(!0),[x,l]=a.useState(!1);if(a.useEffect(()=>{let r=!0,o=new AbortController;const d=async()=>{try{const n=s?`&page=${encodeURIComponent(s)}`:"",i=await fetch(`/api/announcement/active?t=${Date.now()}${n}`,{signal:o.signal});if(i.ok&&r){const b=await i.json();c(b),l(!0)}else i.status===404&&r&&(c(null),l(!0))}catch(n){n.name!=="AbortError"&&r&&(console.error("Failed to fetch announcement:",n),l(!0))}};d();const f=setInterval(()=>{r&&(o.abort(),o=new AbortController,d())},3e4);return()=>{r=!1,o.abort(),clearInterval(f)}},[s]),!x||!e||!e.isActive||!u)return null;const h=()=>{m(!1)};return t.jsxs(t.Fragment,{children:[t.jsx("style",{children:`
        @keyframes marqueeScroll {
          0% { transform: translateX(100%); }
          100% { transform: translateX(-100%); }
        }
        
        .announcement-marquee {
          animation: marqueeScroll ${e.animationSpeed}s linear infinite;
          white-space: nowrap;
          display: block;
        }
      `}),t.jsxs("div",{className:"relative overflow-hidden border-b border-gray-200 dark:border-gray-600",style:{backgroundColor:e.backgroundColor,minHeight:"35px",maxWidth:"100vw",width:"100%",boxSizing:"border-box",border:`${e.bannerBorderWidth||"0px"} ${e.bannerBorderStyle||"solid"} ${e.bannerBorderColor||"#000000"}`},children:[t.jsx("button",{onClick:h,className:"absolute top-2 right-2 z-10 w-6 h-6 flex items-center justify-center rounded-full bg-black/20 hover:bg-black/30 text-white text-sm transition-colors",title:"Close announcement",children:"×"}),t.jsx("div",{className:"py-1 overflow-hidden",style:{maxWidth:"100%",width:"100%"},children:t.jsx("div",{className:"announcement-marquee",style:{color:e.textColor,fontSize:e.fontSize,fontWeight:e.fontWeight,textDecoration:e.textDecoration||"none",fontStyle:e.fontStyle||"normal",textShadow:`${e.textBorderWidth||"0px"} 0 0 ${e.textBorderColor||"#000000"}, 0 ${e.textBorderWidth||"0px"} 0 ${e.textBorderColor||"#000000"}, -${e.textBorderWidth||"0px"} 0 0 ${e.textBorderColor||"#000000"}, 0 -${e.textBorderWidth||"0px"} 0 ${e.textBorderColor||"#000000"}`},children:e.message})})]})]})}export{g as A};
