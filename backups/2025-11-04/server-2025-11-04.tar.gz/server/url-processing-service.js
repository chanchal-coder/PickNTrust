// URL processing service used by bots
// Fetches HTML with proper headers, follows redirects, and extracts product meta

import { URL } from 'node:url';
import { fetch } from 'undici';

async function fetchWithRedirects(inputUrl, maxRedirects = 5) {
  const visited = [];
  let current = inputUrl.startsWith('http') ? inputUrl : `https://${inputUrl}`;
  let lastResponse = null;

  for (let i = 0; i <= maxRedirects; i++) {
    try {
      const res = await fetch(current, {
        method: 'GET',
        redirect: 'manual',
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121 Safari/537.36',
          'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
          'Accept-Language': 'en-IN,en;q=0.9',
          'Cache-Control': 'no-cache'
        }
      });

      lastResponse = res;

      // Handle manual redirects
      if (res.status >= 300 && res.status < 400) {
        const location = res.headers.get('location');
        if (!location) break;
        const nextUrl = location.startsWith('http') ? location : new URL(location, current).toString();
        visited.push(nextUrl);
        current = nextUrl;
        continue;
      }

      // Non-redirect response, read body (decompression handled by undici)
      const text = await res.text();
      return { finalUrl: current, status: res.status, body: text, visited };
    } catch (e) {
      // As a last resort, break with empty body
      return { finalUrl: current, status: 0, body: '', visited };
    }
  }

  // If loop exits due to max redirects
  const body = lastResponse ? await lastResponse.text() : '';
  return { finalUrl: current, status: lastResponse?.status ?? 0, body, visited };
}

function extractMetaFromHtml(html, hostname) {
  const get = (regex) => {
    const m = html.match(regex);
    return m ? m[1].trim() : null;
  };

  // Generic tags
  let title = get(/<meta[^>]+property=["']og:title["'][^>]+content=["']([^"']+)["']/i) || get(/<title>([^<]+)<\/title>/i);
  let description = get(/<meta[^>]+name=["']description["'][^>]+content=["']([^"']+)["']/i) || get(/<meta[^>]+property=["']og:description["'][^>]+content=["']([^"']+)["']/i);
  let image = get(/<meta[^>]+property=["']og:image["'][^>]+content=["']([^"']+)["']/i)
    || get(/<meta[^>]+property=["']og:image:secure_url["'][^>]+content=["']([^"']+)["']/i)
    || get(/<link[^>]+rel=["']image_src["'][^>]+href=["']([^"']+)["']/i)
    || get(/<meta[^>]+property=["']twitter:image["'][^>]+content=["']([^"']+)["']/i);

  // Filter out clearly non-product images (logos, sprites, placeholders, SVGs)
  const isBadImage = (src) => {
    if (!src) return true;
    const s = String(src).toLowerCase();
    return s.endsWith('.svg') || s.includes('sprite') || s.includes('icon') || s.includes('logo') || s.includes('placeholder') || s.includes('via.placeholder');
  };
  if (isBadImage(image)) {
    image = null;
  }

  // JSON-LD blocks often contain canonical product data (name, image, offers)
  const jsonLdMatches = [...html.matchAll(/<script[^>]+type=["']application\/ld\+json["'][^>]*>([\s\S]*?)<\/script>/gi)].map(m => m[1]);
  let jsonLdProduct = null;
  for (const block of jsonLdMatches) {
    try {
      const parsed = JSON.parse(block.trim());
      const candidates = Array.isArray(parsed) ? parsed : [parsed];
      for (const c of candidates) {
        const isProduct = (c['@type'] && /product/i.test(String(c['@type']))) || c.offers || c.name || c.image;
        if (isProduct) { jsonLdProduct = c; break; }
      }
      if (jsonLdProduct) break;
    } catch { /* ignore parse errors */ }
  }
  if (jsonLdProduct) {
    try {
      // Title/Description
      if (!title && typeof jsonLdProduct.name === 'string') title = jsonLdProduct.name.trim();
      if (!description && typeof jsonLdProduct.description === 'string') description = jsonLdProduct.description.trim();

      // Image can be string or array
      const imgField = jsonLdProduct.image;
      if (!image && imgField) {
        if (Array.isArray(imgField)) {
          const firstUrl = imgField.find(u => typeof u === 'string' && /^https?:\/\//i.test(u));
          if (firstUrl) image = firstUrl;
        } else if (typeof imgField === 'string') {
          image = imgField;
        }
      }

      // Price from offers
      const offers = jsonLdProduct.offers;
      const offerObj = Array.isArray(offers) ? offers[0] : offers;
      if (offerObj) {
        const offerPrice = offerObj.price || offerObj.priceSpecification?.price || offerObj.lowPrice || offerObj.highPrice;
        if (!isNaN(parseFloat(String(offerPrice)))) {
          // Normalize price as string with commas preserved only for thousands if present in HTML later
          const p = String(offerPrice);
          // Flipkart/Myntra often provide as number, keep as plain string
          if (!/₹/.test(p)) {
            // leave numeric string as-is
          }
          // Assign if we didn't already find a price via og tags
          // We only set price if our current price is null
          // originalPrice is not reliably present in JSON-LD; skip unless explicitly provided
          // handled below by site-specific heuristics
        }
      }
    } catch { /* ignore JSON-LD mapping issues */ }
  }

  // Amazon-specific fallbacks
  if (!title && hostname.includes('amazon.')) {
    title = get(/<span[^>]+id=["']productTitle["'][^>]*>([^<]+)<\/span>/i) || get(/"name"\s*:\s*"([^"]+)"/i);
  }
  if (!image && hostname.includes('amazon.')) {
    image = get(/"image"\s*:\s*"(https?:[^"']+)"/i)
      || get(/<img[^>]+id=["']landingImage["'][^>]+src=["']([^"']+)["']/i)
      || get(/<img[^>]+id=["']landingImage["'][^>]+data-old-hires=["']([^"']+)["']/i);

    // Parse data-a-dynamic-image JSON map
    if (!image) {
      const dyn = get(/data-a-dynamic-image=["']({[^"']+})["']/i);
      if (dyn) {
        try {
          const map = JSON.parse(dyn.replace(/&quot;/g, '"'));
      const keys = Object.keys(map || {});
      image = keys.find(k => k.startsWith('http')) || null;
    } catch {}
  }
  // Apply bad image filter
  if (isBadImage(image)) image = null;
  }
  }

  // Price handling
  let price = null;
  let originalPrice = null;

  if (hostname.includes('amazon.')) {
    // Prefer prices within corePrice_desktop / a-price blocks
    const priceCore = html.match(/id=["']corePrice_desktop["'][\s\S]*?class=["']a-offscreen["'][^>]*>\s*₹[\s\u00A0]*([\d,]+(?:\.\d+)?)/i);
    const priceOffscreen = html.match(/class=["']a-price[^"']*["'][\s\S]*?class=["']a-offscreen["'][^>]*>\s*₹[\s\u00A0]*([\d,]+(?:\.\d+)?)/i);
    price = (priceCore?.[1] || priceOffscreen?.[1]) || null;

    // Original/MRP price
    const origTextPrice = html.match(/class=["']a-price\s+a-text-price[^"']*["'][\s\S]*?class=["']a-offscreen["'][^>]*>\s*₹[\s\u00A0]*([\d,]+(?:\.\d+)?)/i);
    const origStrike = html.match(/class=["']a-text-strike["'][^>]*>\s*₹?[\s\u00A0]*([\d,]+(?:\.\d+)?)/i);
    originalPrice = (origTextPrice?.[1] || origStrike?.[1]) || null;

    // Avoid capturing coupon/savings amounts like ₹500
    try {
      const pNum = price ? parseFloat(String(price).replace(/,/g, '')) : null;
      if (pNum !== null && isFinite(pNum) && pNum < 1000) {
        price = null;
      }
    } catch {}
  }

  // Flipkart-specific: title, price, original price
  if (hostname.includes('flipkart.')) {
    if (!title) {
      title = get(/<span[^>]+class=["']B_NuCI["'][^>]*>([^<]+)<\/span>/i);
    }
    if (!price) {
      // Current price: <div class="_30jeq3 _16Jk6d">₹43,999</div>
      const fkPrice = html.match(/class=["']_30jeq3[^"']*["'][^>]*>\s*₹[\s\u00A0]*([\d,]+(?:\.\d+)?)/i);
      price = fkPrice?.[1] || null;
    }
    if (!originalPrice) {
      // Original price: <div class="_3I9_wc">₹49,999</div>
      const fkOrig = html.match(/class=["']_3I9_wc[^"']*["'][^>]*>\s*₹?[\s\u00A0]*([\d,]+(?:\.\d+)?)/i);
      originalPrice = fkOrig?.[1] || null;
    }
    // Inline JSON fallback
    if (!price) {
      const inlinePrice = get(/"price"\s*:\s*"?([\d,.]+)"?/i) || get(/"sellingPrice"\s*:\s*"?([\d,.]+)"?/i) || get(/"value"\s*:\s*"?([\d,.]+)"?/i);
      if (inlinePrice) price = inlinePrice;
    }
  }

  // Myntra-specific: title, price, original price
  if (hostname.includes('myntra.')) {
    if (!title) {
      // Title: <h1 class="pdp-title">Product</h1> often with brand in pdp-name
      title = get(/<h1[^>]+class=["']pdp-title["'][^>]*>([^<]+)<\/h1>/i) || get(/<h1[^>]+class=["']pdp-name["'][^>]*>([^<]+)<\/h1>/i);
    }
    if (!price) {
      const myPrice = html.match(/class=["']pdp-price[^"']*["'][^>]*>\s*₹[\s\u00A0]*([\d,]+(?:\.\d+)?)/i) || html.match(/class=["']pdp-discount-price[^"']*["'][^>]*>\s*₹[\s\u00A0]*([\d,]+(?:\.\d+)?)/i);
      price = myPrice?.[1] || price;
    }
    if (!originalPrice) {
      const myOrig = html.match(/class=["']pdp-mrp[^"']*["'][^>]*>\s*₹?[\s\u00A0]*([\d,]+(?:\.\d+)?)/i);
      originalPrice = myOrig?.[1] || originalPrice;
    }
  }

  // Generic fallback: pick the largest ₹ value, but avoid discount/coupon contexts
  if (!price && !hostname.includes('amazon.')) {
    const matches = [...html.matchAll(/₹[\s\u00A0]*([\d,]+(?:\.\d+)?)/gi)];
    const filtered = matches
      .filter((m) => {
        const idx = m.index || html.indexOf(m[0]);
        const context = html.substring(Math.max(0, idx - 40), Math.min(html.length, idx + 60)).toLowerCase();
        return !/(\boff\b|\bsave\b|coupon|discount|cashback|extra|flat)/.test(context);
      })
      .map((m) => m[1]);
    const nums = filtered.map(v => parseFloat(v.replace(/,/g, ''))).filter(n => !isNaN(n));
    if (nums.length > 0) {
      const max = Math.max(...nums);
      const chosen = filtered[nums.indexOf(max)];
      price = chosen || null;
    }
  }

  return { title, description, image, price, originalPrice };
}

function humanizeFromPath(pathname) {
  try {
    const parts = pathname.split('/').filter(Boolean);
    // Prefer last slug before dp or ref segment
    let candidate = parts.find((p) => /-/.test(p) && !/^dp$/i.test(p)) || parts[parts.length - 1] || '';
    candidate = candidate.replace(/([A-Z0-9]{8,})/g, '').replace(/[-_]+/g, ' ').replace(/\s{2,}/g, ' ').trim();
    if (candidate.length > 5) return candidate;
    return '';
  } catch { return ''; }
}

export const urlProcessingService = {
  /**
   * Process a URL and attempt to extract product meta via HTML scraping.
   * Returns { success, productCard?, error? }
   */
  async processURL(url, pageSlug = '') {
    try {
      let targetUrl = url;
      if (!String(targetUrl).startsWith('http')) {
        targetUrl = 'https://' + String(targetUrl);
      }

      // Resolve redirects (shorteners / affiliate wrappers)
      const { finalUrl, body } = await fetchWithRedirects(targetUrl, 5);
      const hostname = (() => { try { return new URL(finalUrl).hostname.replace('www.', ''); } catch { return 'unknown'; } })();

      // Extract meta
  const meta = body ? extractMetaFromHtml(body, hostname) : { title: null, description: null, image: null, price: null };

      // If still missing title, derive from path
      let derivedTitle = meta.title;
      if (!derivedTitle) {
        try {
          const pathname = new URL(finalUrl).pathname;
          derivedTitle = humanizeFromPath(pathname);
        } catch {}
      }

      // Resolve relative image URLs and prefer https
      let finalImage = meta.image || null;
      try {
        if (finalImage && !/^https?:\/\//i.test(finalImage)) {
          finalImage = new URL(finalImage, finalUrl).toString();
        }
        if (finalImage && finalImage.startsWith('http://')) {
          finalImage = finalImage.replace('http://', 'https://');
        }
      } catch {}

      const productCard = {
        name: derivedTitle || `Product from ${hostname}`,
        description: meta.description || '',
        price: meta.price || null,
        originalPrice: meta.originalPrice || null,
        discount: meta.price && meta.originalPrice ? (() => {
          try {
            const p = parseFloat(String(meta.price).replace(/,/g, ''));
            const o = parseFloat(String(meta.originalPrice).replace(/,/g, ''));
            if (isFinite(p) && isFinite(o) && o > p) {
              return Math.round(((o - p) / o) * 100);
            }
          } catch {}
          return null;
        })() : null,
        currency: 'INR',
        imageUrl: finalImage,
        urls: [finalUrl],
        source: hostname,
        pageSlug
      };

      return { success: true, productCard };
    } catch (error) {
      return { success: false, error: String(error?.message || error) };
    }
  }
};