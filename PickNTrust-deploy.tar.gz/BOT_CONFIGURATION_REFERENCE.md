# 🤖 TELEGRAM BOT CONFIGURATION REFERENCE

**⚠️ CONFIDENTIAL - DO NOT COMMIT TO PUBLIC REPOSITORY**

## 📋 ALL 8 BOTS CONFIGURATION

### 1. 🛒 Prime Picks
- **Token:** `8260140807:AAEy6I9xxtYbvddJKDNfRwmcIWDX1Y9pck4`
- **Bot Username:** `@pntamazon_bot`
- **Channel ID:** `-1002955338551`
- **Channel Username:** `pntamazon`
- **Channel Type:** `channel`
- **Affiliate Tag:** `{{URL}}{{SEP}}tag=pickntrust03-21`
- **Affiliate Platform:** Single Amazon
- **Website Page:** `/prime-picks`

### 2. 🔗 Cue Picks
- **Token:** `8352384812:AAE-bwA_3zIB8ZnPG4ZmyEbREBlfijjE32I`
- **Bot Username:** `@cuelinkspnt_bot`
- **Channel ID:** `-1002982344997`
- **Channel Name:** `Cuelinks PNT`
- **Affiliate Tag:** `https://linksredirect.com/?cid=243942&source=linkkit&url=%7B%7BURL_ENC%7D%7D`
- **Affiliate Platform:** Single Cuelinks (all URL types supported)
- **Website Page:** `/cue-picks`

### 3. 💰 Value Picks (Public Channel)
- **Token:** `8293858742:AAGDnH8aN5e-JOvhLQNCR_rWEOicOPji41A`
- **Bot Username:** `@earnkaropnt_bot`
- **Channel ID:** `-1003017626269`
- **Channel Name:** `Value Picks EK`
- **Affiliate Tag:** `https://ekaro.in/enkr2020/?url=%7B%7BURL_ENC%7D%7D&ref=4530348`
- **Affiliate Platform:** Single EarnKaro
- **Website Page:** `/value-picks`

### 4. 🖱️ Click Picks
- **Token:** `8077836519:AAGoSql-Fz9lF_90AKxobprROub89VVKePg`
- **Bot Username:** `@clickpicks_bot`
- **Channel ID:** `-1002981205504`
- **Channel Name:** `Click Picks`
- **Affiliate Platform:** Multiple (Cuelinks, INRDeals, EarnKaro)
- **Website Page:** `/click-picks`

### 5. 🌍 Global Picks
- **Token:** `8341930611:AAHq7sS4Sk6HKoyfUGYwYWHwXZrGOgeWx-E`
- **Bot Username:** `@globalpnt_bot`
- **Channel ID:** `-1002902496654`
- **Channel Name:** `Global Picks`
- **Affiliate Platform:** Multiple (Cuelinks, INRDeals, EarnKaro)
- **Website Page:** `/global-picks`

### 6. ✈️ Travel Picks
- **Token:** `7998139680:AAGVKECApmHNi4LMp2wR3UdVFfYgkT1HwZo`
- **Bot Username:** `@travelpicks_bot`
- **Channel ID:** `-1003047967930`
- **Channel Name:** `Travel Picks`
- **Affiliate Platform:** Multiple (Cuelinks, INRDeals, EarnKaro, etc.)
- **Website Page:** `/travel-picks`

### 7. 🏪 Deals Hub
- **Token:** `8292764619:AAEkfPXIsgNh1JC3n2p6VYo27V-EHepzmBo`
- **Bot Username:** `@dealshubpnt_bot`
- **Channel ID:** `-1003029983162`
- **Channel Name:** `Dealshub PNT`
- **Affiliate Tag:** `id=sha678089037`
- **Affiliate Platform:** Single INRDeals
- **Website Page:** `/deals-hub`

### 8. 📦 Loot Box
- **Token:** `8141266952:AAEosdwI8BkIpSk0f1AVzn8l4iwRnS8HXFQ`
- **Bot Username:** `@deodappnt_bot`
- **Channel ID:** `-1002991047787`
- **Channel Name:** `Deodap PNT`
- **Affiliate Tag:** `{{URL}}{{SEP}}ref=sicvppak`
- **Affiliate Platform:** Deodap
- **Website Page:** `/loot-box`

## 📊 AFFILIATE PLATFORM SUMMARY

### Single Platform Bots:
- **Prime Picks:** Amazon only
- **Cue Picks:** Cuelinks (all URL types)
- **Value Picks:** EarnKaro only
- **Deals Hub:** INRDeals only
- **Loot Box:** Deodap only

### Multi-Platform Bots:
- **Click Picks:** Cuelinks + INRDeals + EarnKaro
- **Global Picks:** Cuelinks + INRDeals + EarnKaro
- **Travel Picks:** Cuelinks + INRDeals + EarnKaro + Others

## 🔐 SECURITY NOTES

- **All tokens are active and valid**
- **Channel IDs are negative (supergroup/channel format)**
- **Affiliate tags use URL encoding placeholders**
- **This file should be added to .gitignore**
- **Never commit tokens to public repositories**

## 🚀 DEPLOYMENT STATUS

- **Total Bots:** 8
- **Webhook Ready:** All configured
- **Database Tables:** All exist
- **Website Pages:** All functional
- **Auto-posting:** Fully operational

---

**Last Updated:** $(date)
**Configuration Status:** ✅ Complete
**System Status:** 🟢 Operational