import express from "express";
import fs from "fs";
import path from "path";
import { nanoid } from "nanoid";
import { fileURLToPath } from "url";
// Fix __dirname for ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
// Lazily load Vite only in development to avoid dev-dependency requirements in production
let viteLogger;
export function log(message, source = "express") {
    const formattedTime = new Date().toLocaleTimeString("en-US", {
        hour: "numeric",
        minute: "2-digit",
        second: "2-digit",
        hour12: true,
    });
    console.log(`${formattedTime} [${source}] ${message}`);
}
export async function setupVite(app, server) {
    try {
        const { createServer: createViteServer, createLogger } = await import('vite');
        const configModule = await import('../vite.config.js');
        const viteConfig = configModule.default ?? configModule;
        viteLogger = createLogger();
        const vite = await createViteServer({
            ...viteConfig,
            configFile: false,
            customLogger: {
                ...viteLogger,
                error: (msg, options) => {
                    viteLogger.error(msg, options);
                    // Don't exit process on Vite errors in development
                    console.error('Vite error (non-fatal):', msg);
                },
            },
            server: {
                middlewareMode: true,
                hmr: {
                    port: 24678,
                    host: 'localhost'
                }
            },
            appType: "custom",
        });
        app.use(vite.middlewares);
        // Handle all non-API routes for SPA
        app.use("*", async (req, res, next) => {
            // Skip API routes
            if (req.originalUrl.startsWith('/api/')) {
                return next();
            }
            const url = req.originalUrl;
            try {
                const clientTemplate = path.resolve(__dirname, "..", "client", "index.html");
                // always reload the index.html file from disk incase it changes
                let template = await fs.promises.readFile(clientTemplate, "utf-8");
                template = template.replace('src="/src/main.tsx"', 'src="/src/main.tsx?v=' + nanoid() + '"');
                const page = await vite.transformIndexHtml(url, template);
                res.status(200).set({ "Content-Type": "text/html" }).end(page);
            }
            catch (e) {
                vite.ssrFixStacktrace(e);
                next(e);
            }
        });
        console.log('✅ Vite middleware setup completed successfully');
    }
    catch (error) {
        console.error('❌ Failed to setup Vite development server:', error);
        throw error;
    }
}
export function serveStatic(app) {
    // When running in production, the server is in dist/server
    // and the static files are in dist/public
    const distPath = path.resolve(__dirname, "..", "dist", "public");
    if (!fs.existsSync(distPath)) {
        throw new Error("Could not find the build directory: " + distPath + ", make sure to build the client first");
    }
    app.use(express.static(distPath));
    // fall through to index.html if the file doesn't exist
    app.use("*", (_req, res) => {
        res.sendFile(path.resolve(distPath, "index.html"));
    });
}
