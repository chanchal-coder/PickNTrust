import TelegramBot from 'node-telegram-bot-api';
import Database from 'better-sqlite3';
import path from 'path';
import { fileURLToPath } from 'url';
import { urlProcessingService } from './url-processing-service.js';
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
// Travel Picks Bot Configuration
const TRAVEL_BOT_CONFIG = {
    botToken: '7998139680:AAGVKECApmHNi4LMp2wR3UdVFfYgkT1HwZo',
    botUsername: 'travelpicks_bot',
    channelId: '-1003047967930',
    channelName: 'Travel Picks',
    tableName: 'travel_products'
};
// Travel category mapping
const TRAVEL_CATEGORIES = {
    'flight': 'flights',
    'flights': 'flights',
    'hotel': 'hotels',
    'hotels': 'hotels',
    'tour': 'tours',
    'tours': 'tours',
    'package': 'packages',
    'packages': 'packages',
    'cruise': 'cruises',
    'cruises': 'cruises',
    'bus': 'bus',
    'train': 'train',
    'car': 'car-rental',
    'rental': 'car-rental'
};
// Travel affiliate templates
const TRAVEL_AFFILIATE_TEMPLATES = {
    'makemytrip.com': 'utm_source=pickntrust&utm_campaign=travel',
    'booking.com': 'aid=1234567',
    'redbus.in': 'utm_source=pickntrust',
    'irctc.co.in': 'utm_source=pickntrust',
    'goibibo.com': 'utm_source=pickntrust',
    'cleartrip.com': 'utm_source=pickntrust',
    'yatra.com': 'utm_source=pickntrust'
};
class TravelPicksBot {
    bot = null;
    db;
    isInitialized = false;
    constructor() {
        // Initialize database
        const dbPath = path.join(__dirname, '..', 'database.sqlite');
        this.db = new Database(dbPath);
        // Ensure travel_products table exists
        this.initializeDatabase();
    }
    initializeDatabase() {
        try {
            // Create travel_products table if it doesn't exist
            this.db.exec(`
        CREATE TABLE IF NOT EXISTS travel_products (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT NOT NULL,
          description TEXT,
          price TEXT,
          original_price TEXT,
          currency TEXT DEFAULT 'INR',
          image_url TEXT,
          affiliate_url TEXT,
          category TEXT NOT NULL,
          rating REAL DEFAULT 0,
          review_count INTEGER DEFAULT 0,
          discount TEXT,
          is_featured BOOLEAN DEFAULT 0,
          affiliate_network TEXT,
          telegram_message_id INTEGER,
          telegram_channel_id TEXT,
          click_count INTEGER DEFAULT 0,
          conversion_count INTEGER DEFAULT 0,
          processing_status TEXT DEFAULT 'active',
          expires_at INTEGER,
          created_at INTEGER DEFAULT (strftime('%s', 'now')),
          updated_at INTEGER DEFAULT (strftime('%s', 'now')),
          has_limited_offer BOOLEAN DEFAULT 0,
          limited_offer_text TEXT
        )
      `);
            // Create travel_categories table for category management
            this.db.exec(`
        CREATE TABLE IF NOT EXISTS travel_categories (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          slug TEXT UNIQUE NOT NULL,
          name TEXT NOT NULL,
          icon TEXT,
          description TEXT,
          is_active BOOLEAN DEFAULT 1,
          sort_order INTEGER DEFAULT 0,
          created_at INTEGER DEFAULT (strftime('%s', 'now'))
        )
      `);
            // Insert default travel categories if they don't exist
            const defaultCategories = [
                { slug: 'flights', name: 'Flights', icon: 'fas fa-plane', description: 'Flight booking and deals' },
                { slug: 'hotels', name: 'Hotels', icon: 'fas fa-bed', description: 'Hotel booking and deals' },
                { slug: 'tours', name: 'Tours', icon: 'fas fa-map-marked-alt', description: 'Tour packages and experiences' },
                { slug: 'packages', name: 'Packages', icon: 'fas fa-suitcase', description: 'Complete travel packages' },
                { slug: 'cruises', name: 'Cruises', icon: 'fas fa-ship', description: 'Cruise deals and packages' },
                { slug: 'bus', name: 'Bus', icon: 'fas fa-bus', description: 'Bus booking and deals' },
                { slug: 'train', name: 'Train', icon: 'fas fa-train', description: 'Train booking and deals' },
                { slug: 'car-rental', name: 'Car Rental', icon: 'fas fa-car', description: 'Car rental deals' }
            ];
            const insertCategory = this.db.prepare(`
        INSERT OR IGNORE INTO travel_categories (slug, name, icon, description, sort_order)
        VALUES (?, ?, ?, ?, ?)
      `);
            defaultCategories.forEach((category, index) => {
                insertCategory.run(category.slug, category.name, category.icon, category.description, index);
            });
            console.log('✅ Travel database initialized successfully');
        }
        catch (error) {
            console.error('❌ Error initializing travel database:', error);
        }
    }
    async initialize() {
        if (this.isInitialized) {
            console.log('🧳 Travel Picks bot already initialized');
            return;
        }
        try {
            console.log('🧳 Initializing Travel Picks bot...');
            // Initialize bot
            this.bot = new TelegramBot(TRAVEL_BOT_CONFIG.botToken, { polling: false });
            // Set up message handlers
            this.setupMessageHandlers();
            // Set up error handlers
            this.setupErrorHandlers();
            this.isInitialized = true;
            console.log('✅ Travel Picks bot initialized successfully');
            console.log(`📺 Monitoring channel: ${TRAVEL_BOT_CONFIG.channelName} (${TRAVEL_BOT_CONFIG.channelId})`);
        }
        catch (error) {
            console.error('❌ Failed to initialize Travel Picks bot:', error);
            this.isInitialized = false;
        }
    }
    setupMessageHandlers() {
        if (!this.bot)
            return;
        // Handle channel posts
        this.bot.on('channel_post', async (msg) => {
            if (msg.chat.id.toString() === TRAVEL_BOT_CONFIG.channelId) {
                await this.handleMessage(msg);
            }
        });
        // Handle edited channel posts
        this.bot.on('edited_channel_post', async (msg) => {
            if (msg.chat.id.toString() === TRAVEL_BOT_CONFIG.channelId) {
                await this.handleMessage(msg);
            }
        });
    }
    setupErrorHandlers() {
        if (!this.bot)
            return;
        this.bot.on('polling_error', (error) => {
            console.error('🧳 Travel Picks bot polling error:', error);
        });
        this.bot.on('error', (error) => {
            console.error('🧳 Travel Picks bot error:', error);
        });
    }
    async processMessage(msg) {
        return this.handleMessage(msg);
    }
    async handleMessage(msg) {
        try {
            console.log('🧳 Processing travel message:', msg.message_id);
            // Extract text from message
            const text = msg.text || msg.caption || '';
            if (!text) {
                console.log('⚠️ No text found in message');
                return;
            }
            // Extract URLs from message
            const urls = this.extractUrls(text);
            if (urls.length === 0) {
                console.log('⚠️ No URLs found in message');
                return;
            }
            // Process each URL
            for (const url of urls) {
                await this.processUrl(url, text, msg);
            }
        }
        catch (error) {
            console.error('❌ Error processing travel message:', error);
        }
    }
    extractUrls(text) {
        const urlRegex = /https?:\/\/[^\s]+/g;
        return text.match(urlRegex) || [];
    }
    async processUrl(url, messageText, msg) {
        try {
            // Process URL to get product information via processing pipeline
            const result = await urlProcessingService.processURL(url, 'travel-picks');
            if (!result?.success || !result.productCard) {
                console.log('⚠️ Could not extract product info from URL');
                return;
            }
            const product = result.productCard;
            // Detect travel category from URL and text
            const category = this.detectTravelCategory(url, messageText);
            // Apply travel affiliate template (fallback)
            const affiliateUrlFallback = this.applyAffiliateTemplate(url);
            // Extract price information from message text
            const priceInfo = this.extractPriceInfo(messageText);
            // Save to database
            await this.saveToDatabase({
                name: product.name || this.extractTitleFromMessage(messageText),
                description: product.description || messageText.substring(0, 500),
                price: priceInfo.price ?? product.price,
                original_price: priceInfo.originalPrice ?? product.originalPrice,
                currency: product.currency || 'INR',
                image_url: product.imageUrl,
                affiliate_url: product.affiliateUrl || affiliateUrlFallback,
                category: category || product.category,
                rating: Number(product.rating) || 0,
                review_count: product.reviewCount || 0,
                discount: priceInfo.discount ?? (product.discount ? String(product.discount) : undefined),
                is_featured: this.isFeaturedDeal(messageText),
                affiliate_network: product.affiliateNetwork || this.getAffiliateNetwork(url),
                telegram_message_id: msg.message_id,
                telegram_channel_id: msg.chat.id.toString(),
                processing_status: 'active'
            });
            console.log('✅ Travel product saved successfully');
        }
        catch (error) {
            console.error('❌ Error processing travel URL:', error);
        }
    }
    detectTravelCategory(url, text) {
        // Check URL for category hints
        const urlLower = url.toLowerCase();
        const textLower = text.toLowerCase();
        // Check for specific travel sites and their categories
        if (urlLower.includes('flight') || textLower.includes('flight'))
            return 'flights';
        if (urlLower.includes('hotel') || textLower.includes('hotel'))
            return 'hotels';
        if (urlLower.includes('tour') || textLower.includes('tour'))
            return 'tours';
        if (urlLower.includes('package') || textLower.includes('package'))
            return 'packages';
        if (urlLower.includes('cruise') || textLower.includes('cruise'))
            return 'cruises';
        if (urlLower.includes('bus') || textLower.includes('bus'))
            return 'bus';
        if (urlLower.includes('train') || textLower.includes('train'))
            return 'train';
        if (urlLower.includes('car') || urlLower.includes('rental') || textLower.includes('car rental'))
            return 'car-rental';
        // Default to packages for general travel deals
        return 'packages';
    }
    applyAffiliateTemplate(url) {
        try {
            const urlObj = new URL(url);
            const domain = urlObj.hostname.replace('www.', '');
            const template = TRAVEL_AFFILIATE_TEMPLATES[domain];
            if (template) {
                // Add affiliate parameters
                const separator = url.includes('?') ? '&' : '?';
                return `${url}${separator}${template}`;
            }
            return url;
        }
        catch (error) {
            console.error('Error applying affiliate template:', error);
            return url;
        }
    }
    extractPriceInfo(text) {
        const priceRegex = /₹[\d,]+/g;
        const prices = text.match(priceRegex) || [];
        const discountRegex = /(\d+)%\s*off/i;
        const discountMatch = text.match(discountRegex);
        return {
            price: prices[0],
            originalPrice: prices[1],
            discount: discountMatch ? `${discountMatch[1]}% OFF` : undefined
        };
    }
    extractTitleFromMessage(text) {
        // Extract first line or first 100 characters as title
        const firstLine = text.split('\n')[0];
        return firstLine.length > 100 ? firstLine.substring(0, 100) + '...' : firstLine;
    }
    isFeaturedDeal(text) {
        const featuredKeywords = ['featured', 'exclusive', 'limited', 'special', 'premium'];
        const textLower = text.toLowerCase();
        return featuredKeywords.some(keyword => textLower.includes(keyword));
    }
    getAffiliateNetwork(url) {
        try {
            const urlObj = new URL(url);
            const domain = urlObj.hostname.replace('www.', '');
            const networkMap = {
                'makemytrip.com': 'MakeMyTrip',
                'booking.com': 'Booking.com',
                'redbus.in': 'RedBus',
                'irctc.co.in': 'IRCTC',
                'goibibo.com': 'Goibibo',
                'cleartrip.com': 'Cleartrip',
                'yatra.com': 'Yatra'
            };
            return networkMap[domain] || 'Direct';
        }
        catch (error) {
            return 'Direct';
        }
    }
    async saveToDatabase(productData) {
        try {
            const insertQuery = this.db.prepare(`
        INSERT INTO travel_products (
          name, description, price, original_price, currency, image_url, affiliate_url,
          category, rating, review_count, discount, is_featured, affiliate_network,
          telegram_message_id, telegram_channel_id, processing_status, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);
            insertQuery.run(productData.name, productData.description, productData.price, productData.original_price, productData.currency, productData.image_url, productData.affiliate_url, productData.category, productData.rating, productData.review_count, productData.discount, productData.is_featured ? 1 : 0, productData.affiliate_network, productData.telegram_message_id, productData.telegram_channel_id, productData.processing_status, Math.floor(Date.now() / 1000));
            console.log(`✅ Saved travel product: ${productData.name} (${productData.category})`);
        }
        catch (error) {
            console.error('❌ Error saving to database:', error);
        }
    }
    async stop() {
        if (this.bot) {
            try {
                // No need to stop polling since it's disabled
                console.log('🧳 Travel Picks bot stopped');
            }
            catch (error) {
                console.error('❌ Error stopping Travel Picks bot:', error);
            }
        }
        if (this.db) {
            this.db.close();
        }
        this.isInitialized = false;
    }
    getStatus() {
        return {
            isInitialized: this.isInitialized,
            channelId: TRAVEL_BOT_CONFIG.channelId,
            channelName: TRAVEL_BOT_CONFIG.channelName
        };
    }
}
// Export singleton instance
export const travelPicksBot = new TravelPicksBot();
// Auto-initialize if not in test environment
if (process.env.NODE_ENV !== 'test') {
    travelPicksBot.initialize().catch(console.error);
}
// Graceful shutdown
process.on('SIGINT', async () => {
    console.log('🧳 Shutting down Travel Picks bot...');
    await travelPicksBot.stop();
    process.exit(0);
});
process.on('SIGTERM', async () => {
    console.log('🧳 Shutting down Travel Picks bot...');
    await travelPicksBot.stop();
    process.exit(0);
});
