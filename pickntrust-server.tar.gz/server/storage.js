// @ts-nocheck
import { products, blogPosts, newsletterSubscribers, categories, affiliateNetworks, adminUsers, announcements, videoContent, canvaSettings, canvaPosts, canvaTemplates } from "../shared/sqlite-schema.js";
import { db, sqliteDb } from "./db.js";
import { eq, desc, ne } from "drizzle-orm";
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
// ESM-compatible __dirname/__filename shims
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
// Utility functions for consistent timestamp handling
const toUnixTimestamp = (date) => Math.floor(date.getTime() / 1000);
const fromUnixTimestamp = (timestamp) => new Date(timestamp * 1000);
// Validation helpers
const validateProduct = (product) => {
    // Make validation permissive: accept missing fields and normalize where possible
    if (!product || typeof product !== 'object')
        return;
    // Name fallback (no compulsion)
    if (!product.name || typeof product.name !== 'string' || !product.name.trim()) {
        product.name = 'Untitled';
    }
    // Normalize flags
    const isService = Boolean(product.isService);
    const isAIApp = Boolean(product.isAIApp);
    const isFree = Boolean(product.isFree) || (typeof product.pricingType === 'string' && product.pricingType.toLowerCase() === 'free');
    // Numeric normalization helper
    const normalizeNumber = (v) => {
        if (v === undefined || v === null || v === '')
            return null;
        const s = typeof v === 'string' ? v.replace(/[^\d.]/g, '') : v;
        const n = typeof s === 'string' ? parseFloat(s) : Number(s);
        return isNaN(n) ? null : n;
    };
    // Price normalization (no strict requirement)
    const priceNum = normalizeNumber(product.price);
    const monthlyNum = normalizeNumber(product.monthlyPrice);
    const yearlyNum = normalizeNumber(product.yearlyPrice);
    if (isFree) {
        product.pricingType = 'free';
        // Keep price blank when free
        product.price = '';
        product.monthlyPrice = null;
        product.yearlyPrice = null;
    }
    else if (isService || isAIApp) {
        // Accept any provided pricing; fallback to 0 if none
        if (typeof product.pricingType === 'string') {
            const pt = product.pricingType.toLowerCase();
            if (pt === 'monthly' && monthlyNum !== null) {
                product.price = monthlyNum;
            }
            else if (pt === 'yearly' && yearlyNum !== null) {
                product.price = yearlyNum;
            }
            else if (pt === 'one-time' && priceNum !== null) {
                product.price = priceNum;
            }
            else {
                // Leave price blank if nothing valid is provided
                product.price = priceNum ?? monthlyNum ?? yearlyNum ?? null;
            }
        }
        else {
            // Leave price blank if nothing valid is provided
            product.price = priceNum ?? monthlyNum ?? yearlyNum ?? null;
        }
    }
    else {
        // Regular products: allow missing/invalid price, keep blank instead of forcing 0
        product.price = priceNum !== null && priceNum >= 0 ? priceNum : null;
    }
    // Original price normalization
    const origNum = normalizeNumber(product.originalPrice);
    product.originalPrice = origNum !== null ? origNum : null;
    // Rating normalization (no strict requirement)
    if (product.rating !== undefined && product.rating !== null && product.rating !== '') {
        const r = normalizeNumber(product.rating);
        product.rating = r === null ? 4.5 : Math.max(1, Math.min(5, r));
    }
};
const validateVideoContent = (video) => {
    if (!video.title?.trim())
        throw new Error('Video title is required');
    if (!video.videoUrl?.trim())
        throw new Error('Video URL is required');
    if (!video.platform?.trim())
        throw new Error('Platform is required');
};
const validateBlogPost = (blog) => {
    if (!blog.title?.trim())
        throw new Error('Blog title is required');
    // Allow either rich content or a PDF URL
    const hasContent = !!blog.content && !!blog.content.trim();
    const hasPdf = !!blog.pdfUrl && !!String(blog.pdfUrl).trim();
    if (!hasContent && !hasPdf)
        throw new Error('Blog content or PDF is required');
};
export class DatabaseStorage {
    sqliteDb;
    constructor() {
        this.sqliteDb = sqliteDb;
    }
    // Products - Using unified_content table
    async getProducts() {
        try {
            console.log('🔍 DatabaseStorage: Getting products from unified_content...');
            console.log('📊 Database connection status:', db ? 'Connected' : 'Not connected');
            // Query unified_content table instead of products
            const Database = (await import('better-sqlite3')).default;
            const dbFile = path.join(__dirname, '..', 'database.sqlite');
            const rawDb = new Database(dbFile);
            const directResult = this.sqliteDb.prepare(`
        SELECT 
          id,
          title as name,
          description,
          price,
          original_price as originalPrice,
          image_url as imageUrl,
          affiliate_url as affiliateUrl,
          category,
          rating,
          review_count as reviewCount,
          discount,
          currency,
          is_active as isActive,
          is_featured as isFeatured,
          created_at as createdAt,
          updated_at as updatedAt
        FROM unified_content 
        WHERE content_type = 'product' AND is_active = 1
        ORDER BY id DESC
      `).all();
            rawDb.close();
            console.log(`✅ DatabaseStorage: Found ${directResult.length} products from unified_content`);
            if (directResult.length > 0) {
                console.log('📝 Sample product:', { id: directResult[0].id, name: directResult[0].name, price: directResult[0].price });
            }
            return directResult;
        }
        catch (error) {
            console.error('❌ DatabaseStorage: Error getting products from unified_content:', error);
            return [];
        }
    }
    async getFeaturedProducts() {
        try {
            console.log('🔍 DatabaseStorage: Getting featured products from unified_content...');
            const Database = (await import('better-sqlite3')).default;
            const dbFile = path.join(__dirname, '..', 'database.sqlite');
            const rawDb = new Database(dbFile);
            const directResult = this.sqliteDb.prepare(`
        SELECT 
          id,
          title as name,
          description,
          price,
          original_price as originalPrice,
          image_url as imageUrl,
          affiliate_url as affiliateUrl,
          category,
          rating,
          review_count as reviewCount,
          discount,
          currency,
          is_active as isActive,
          is_featured as isFeatured,
          created_at as createdAt,
          updated_at as updatedAt
        FROM unified_content 
        WHERE content_type = 'product' AND is_active = 1 AND is_featured = 1
        ORDER BY id DESC
      `).all();
            rawDb.close();
            console.log(`✅ DatabaseStorage: Found ${directResult.length} featured products from unified_content`);
            return directResult;
        }
        catch (error) {
            console.error('❌ DatabaseStorage: Error getting featured products from unified_content:', error);
            return [];
        }
    }
    async getServiceProducts() {
        try {
            console.log('🔍 DatabaseStorage: Getting service products from unified_content...');
            const Database = (await import('better-sqlite3')).default;
            const dbFile = path.join(__dirname, '..', 'database.sqlite');
            const rawDb = new Database(dbFile);
            const directResult = this.sqliteDb.prepare(`
        SELECT 
          id,
          title as name,
          description,
          price,
          original_price as originalPrice,
          image_url as imageUrl,
          affiliate_url as affiliateUrl,
          category,
          rating,
          review_count as reviewCount,
          discount,
          currency,
          is_active as isActive,
          is_featured as isFeatured,
          created_at as createdAt,
          updated_at as updatedAt
        FROM unified_content 
        WHERE content_type = 'product' AND is_active = 1 AND is_service = 1
        ORDER BY id DESC
      `).all();
            rawDb.close();
            console.log(`✅ DatabaseStorage: Found ${directResult.length} service products from unified_content`);
            return directResult;
        }
        catch (error) {
            console.error('❌ DatabaseStorage: Error getting service products from unified_content:', error);
            return [];
        }
    }
    async getAIAppsProducts() {
        try {
            console.log('🔍 DatabaseStorage: Getting AI Apps products from unified_content...');
            const Database = (await import('better-sqlite3')).default;
            const dbFile = path.join(__dirname, '..', 'database.sqlite');
            const rawDb = new Database(dbFile);
            const directResult = this.sqliteDb.prepare(`
        SELECT 
          id,
          title as name,
          description,
          price,
          original_price as originalPrice,
          image_url as imageUrl,
          affiliate_url as affiliateUrl,
          category,
          rating,
          review_count as reviewCount,
          discount,
          currency,
          is_active as isActive,
          is_featured as isFeatured,
          created_at as createdAt,
          updated_at as updatedAt
        FROM unified_content 
        WHERE content_type = 'product' AND is_active = 1 AND is_ai_app = 1
        ORDER BY id DESC
      `).all();
            rawDb.close();
            console.log(`✅ DatabaseStorage: Found ${directResult.length} AI Apps products from unified_content`);
            return directResult;
        }
        catch (error) {
            console.error('❌ DatabaseStorage: Error getting AI Apps products from unified_content:', error);
            return [];
        }
    }
    async getProductsByCategory(category) {
        try {
            console.log(`🔍 DatabaseStorage: Getting products by category '${category}' from unified_content...`);
            const Database = (await import('better-sqlite3')).default;
            const dbFile = path.join(__dirname, '..', 'database.sqlite');
            const rawDb = new Database(dbFile);
            const directResult = this.sqliteDb.prepare(`
        SELECT 
          id,
          title as name,
          description,
          price,
          original_price as originalPrice,
          image_url as imageUrl,
          affiliate_url as affiliateUrl,
          category,
          rating,
          review_count as reviewCount,
          discount,
          currency,
          is_active as isActive,
          is_featured as isFeatured,
          created_at as createdAt,
          updated_at as updatedAt
        FROM unified_content 
        WHERE content_type = 'product' AND is_active = 1 AND category = ?
        ORDER BY id DESC
      `).all(category);
            rawDb.close();
            console.log(`✅ DatabaseStorage: Found ${directResult.length} products in category '${category}' from unified_content`);
            return directResult;
        }
        catch (error) {
            console.error(`❌ DatabaseStorage: Error getting products by category '${category}' from unified_content:`, error);
            return [];
        }
    }
    async getProduct(id) {
        try {
            console.log(`🔍 DatabaseStorage: Getting product ${id} from unified_content...`);
            const Database = (await import('better-sqlite3')).default;
            const dbFile = path.join(__dirname, '..', 'database.sqlite');
            const rawDb = new Database(dbFile);
            const directResult = this.sqliteDb.prepare(`
        SELECT 
          id,
          title as name,
          description,
          price,
          original_price as originalPrice,
          image_url as imageUrl,
          affiliate_url as affiliateUrl,
          category,
          rating,
          review_count as reviewCount,
          discount,
          currency,
          is_active as isActive,
          is_featured as isFeatured,
          created_at as createdAt,
          updated_at as updatedAt
        FROM unified_content 
        WHERE content_type = 'product' AND id = ?
      `).get(id);
            rawDb.close();
            if (directResult) {
                console.log(`✅ DatabaseStorage: Found product ${id} from unified_content`);
                return directResult;
            }
            else {
                console.log(`⚠️ DatabaseStorage: Product ${id} not found in unified_content`);
                return undefined;
            }
        }
        catch (error) {
            console.error(`❌ DatabaseStorage: Error getting product ${id} from unified_content:`, error);
            return undefined;
        }
    }
    // Categories with comprehensive fallback handling
    async getCategories() {
        try {
            // EMERGENCY FIX: Direct database access to restore categories immediately
            const Database = (await import('better-sqlite3')).default;
            const dbFile = path.join(__dirname, '..', '..', '..', 'database.sqlite');
            const rawDb = new Database(dbFile);
            const result = rawDb.prepare(`
        SELECT id, name, icon, color, description,
               parent_id as parentId,
               COALESCE(is_for_products, 1) as isForProducts,
               COALESCE(is_for_services, 0) as isForServices,
               COALESCE(is_for_ai_apps, 0) as isForAIApps,
               COALESCE(display_order, 0) as displayOrder
        FROM categories 
        ORDER BY COALESCE(display_order, id)
      `).all();
            rawDb.close();
            console.log(`Success Categories loaded successfully: ${result.length} categories found`);
            return result;
        }
        catch (error) {
            console.error('Error Categories loading failed:', error);
            // Return hardcoded essential categories as absolute fallback
            return [
                { id: 1, name: 'Electronics', icon: 'Mobile', color: '#3B82F6', description: 'Electronic devices', displayOrder: 1, isForProducts: true, isForServices: false, isForAIApps: false },
                { id: 2, name: 'Fashion', icon: '👕', color: '#EC4899', description: 'Clothing and accessories', displayOrder: 2, isForProducts: true, isForServices: false, isForAIApps: false },
                { id: 3, name: 'Home & Kitchen', icon: 'Home', color: '#10B981', description: 'Home appliances', displayOrder: 3, isForProducts: true, isForServices: false, isForAIApps: false }
            ];
        }
    }
    async getCategoriesByPage(page) {
        try {
            const Database = (await import('better-sqlite3')).default;
            const dbFile = path.join(__dirname, '..', 'database.sqlite');
            const rawDb = new Database(dbFile);
            const result = rawDb.prepare(`
        SELECT DISTINCT category, subcategory
        FROM unified_content
        WHERE display_pages LIKE '%' || ? || '%' AND content_type = 'product'
      `).all(page);
            rawDb.close();
            const categories = new Set();
            result.forEach((item) => {
                if (item.category)
                    categories.add(item.category);
                if (item.subcategory)
                    categories.add(item.subcategory);
            });
            return Array.from(categories);
        }
        catch (error) {
            console.error('Error fetching categories by page:', error);
            return [];
        }
    }
    async getProductCategories() {
        try {
            return await db.select().from(categories)
                .where(eq(categories.isForProducts, true))
                .orderBy(categories.displayOrder, categories.name);
        }
        catch (error) {
            console.log('DatabaseStorage: Product categories query failed, using fallback');
            const allCategories = await this.getCategories();
            return allCategories.filter(cat => cat.isForProducts);
        }
    }
    async getServiceCategories() {
        try {
            return await db.select().from(categories)
                .where(eq(categories.isForServices, true))
                .orderBy(categories.displayOrder, categories.name);
        }
        catch (error) {
            console.log('DatabaseStorage: Service categories query failed, using fallback');
            const allCategories = await this.getCategories();
            return allCategories.filter(cat => cat.isForServices);
        }
    }
    async getAIAppCategories() {
        try {
            return await db.select().from(categories)
                .where(eq(categories.isForAIApps, true))
                .orderBy(categories.displayOrder, categories.name);
        }
        catch (error) {
            console.log('DatabaseStorage: AI App categories query failed, using fallback');
            const allCategories = await this.getCategories();
            return allCategories.filter(cat => cat.isForAIApps);
        }
    }
    async getCategoriesWithSubcategories() {
        try {
            const Database = (await import('better-sqlite3')).default;
            const dbFile = path.join(__dirname, '..', '..', '..', 'database.sqlite');
            const rawDb = new Database(dbFile);
            const result = rawDb.prepare(`
        SELECT id, name, icon, color, description,
               parent_id as parentId,
               COALESCE(is_for_products, 1) as isForProducts,
               COALESCE(is_for_services, 0) as isForServices,
               COALESCE(is_for_ai_apps, 0) as isForAIApps,
               COALESCE(display_order, 0) as displayOrder
        FROM categories 
        ORDER BY COALESCE(parent_id, 0), COALESCE(display_order, id * 10)
      `).all();
            rawDb.close();
            return result;
        }
        catch (error) {
            console.log('DatabaseStorage: getCategoriesWithSubcategories failed, using fallback');
            return await this.getCategories();
        }
    }
    async getMainCategories() {
        try {
            const Database = (await import('better-sqlite3')).default;
            const dbFile = path.join(__dirname, '..', '..', '..', 'database.sqlite');
            const rawDb = new Database(dbFile);
            const result = rawDb.prepare(`
        SELECT id, name, icon, color, description,
               parent_id as parentId,
               COALESCE(is_for_products, 1) as isForProducts,
               COALESCE(is_for_services, 0) as isForServices,
               COALESCE(is_for_ai_apps, 0) as isForAIApps,
               COALESCE(display_order, 0) as displayOrder
        FROM categories 
        WHERE parent_id IS NULL
        ORDER BY COALESCE(display_order, id * 10)
      `).all();
            rawDb.close();
            return result;
        }
        catch (error) {
            console.log('DatabaseStorage: getMainCategories failed, using fallback');
            const allCategories = await this.getCategories();
            return allCategories.filter(cat => !cat.parentId);
        }
    }
    async getSubcategories(parentId) {
        try {
            const Database = (await import('better-sqlite3')).default;
            const dbFile = path.join(__dirname, '..', '..', '..', 'database.sqlite');
            const rawDb = new Database(dbFile);
            const result = rawDb.prepare(`
        SELECT id, name, icon, color, description,
               parent_id as parentId,
               COALESCE(is_for_products, 1) as isForProducts,
               COALESCE(is_for_services, 0) as isForServices,
               COALESCE(is_for_ai_apps, 0) as isForAIApps,
               COALESCE(display_order, 0) as displayOrder
        FROM categories 
        WHERE parent_id = ?
        ORDER BY COALESCE(display_order, id * 10)
      `).all(parentId);
            rawDb.close();
            return result;
        }
        catch (error) {
            console.log('DatabaseStorage: getSubcategories failed, using fallback');
            const allCategories = await this.getCategories();
            return allCategories.filter(cat => cat.parentId === parentId);
        }
    }
    async addCategory(category) {
        try {
            const [newCategory] = await db
                .insert(categories)
                .values(category)
                .returning();
            return newCategory;
        }
        catch (error) {
            console.log('DatabaseStorage: Add category failed, trying raw SQL fallback...');
            try {
                // Use raw SQL with proper column handling
                const Database = (await import('better-sqlite3')).default;
                const dbFile = 'database.sqlite';
                const rawDb = new Database(dbFile);
                // Insert with proper column mapping and defaults
                const insertResult = rawDb.prepare(`
          INSERT INTO categories (name, icon, color, description, is_for_products, is_for_services, is_for_ai_apps, display_order)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        `).run(category.name, category.icon, category.color, category.description, category.isForProducts !== undefined ? (category.isForProducts ? 1 : 0) : 1, category.isForServices !== undefined ? (category.isForServices ? 1 : 0) : 0, category.isForAIApps !== undefined ? (category.isForAIApps ? 1 : 0) : 0, category.displayOrder || 0);
                // Get the inserted category
                const newCategory = rawDb.prepare(`
          SELECT id, name, icon, color, description,
                 is_for_products as isForProducts,
                 is_for_services as isForServices,
                 is_for_ai_apps as isForAIApps,
                 display_order as displayOrder
          FROM categories WHERE id = ?
        `).get(insertResult.lastInsertRowid);
                rawDb.close();
                return newCategory;
            }
            catch (fallbackError) {
                console.log('DatabaseStorage: Add category fallback failed:', fallbackError);
                throw new Error(`Failed to add category: ${fallbackError?.message || 'Unknown error'}`);
            }
        }
    }
    async updateCategory(id, updates) {
        try {
            console.log(`DatabaseStorage: updateCategory called with id=${id}, updates=`, updates);
            // Use raw SQL for reliable updates
            const Database = (await import('better-sqlite3')).default;
            const dbFile = path.join(__dirname, '..', '..', '..', 'database.sqlite');
            const rawDb = new Database(dbFile);
            // First check if category exists
            const existingCategory = rawDb.prepare('SELECT id FROM categories WHERE id = ?').get(id);
            if (!existingCategory) {
                console.log(`DatabaseStorage: Category with id=${id} not found`);
                rawDb.close();
                return null;
            }
            // Handle displayOrder update specifically (most common case)
            if (updates.displayOrder !== undefined && Object.keys(updates).length === 1) {
                console.log(`DatabaseStorage: Updating displayOrder for id=${id} to ${updates.displayOrder}`);
                const updateResult = rawDb.prepare(`
          UPDATE categories 
          SET display_order = ? 
          WHERE id = ?
        `).run(updates.displayOrder, id);
                console.log(`DatabaseStorage: Update result:`, updateResult);
                if (updateResult.changes === 0) {
                    console.log(`DatabaseStorage: No rows updated for id=${id}`);
                    rawDb.close();
                    return null;
                }
                // Fetch and return the updated category
                const updatedCategory = rawDb.prepare(`
          SELECT id, name, icon, color, description,
                 COALESCE(is_for_products, 1) as isForProducts,
                 COALESCE(is_for_services, 0) as isForServices,
                 COALESCE(is_for_ai_apps, 0) as isForAIApps,
                 COALESCE(display_order, 0) as displayOrder
          FROM categories 
          WHERE id = ?
        `).get(id);
                rawDb.close();
                console.log(`DatabaseStorage: Returning updated category:`, updatedCategory);
                return updatedCategory;
            }
            // Handle other field updates (fallback to original logic)
            const setClauses = [];
            const values = [];
            if (updates.name !== undefined) {
                setClauses.push('name = ?');
                values.push(updates.name);
            }
            if (updates.description !== undefined) {
                setClauses.push('description = ?');
                values.push(updates.description);
            }
            if (updates.icon !== undefined) {
                setClauses.push('icon = ?');
                values.push(updates.icon);
            }
            if (updates.color !== undefined) {
                setClauses.push('color = ?');
                values.push(updates.color);
            }
            if (updates.isForProducts !== undefined) {
                setClauses.push('is_for_products = ?');
                values.push(updates.isForProducts ? 1 : 0);
            }
            if (updates.isForServices !== undefined) {
                setClauses.push('is_for_services = ?');
                values.push(updates.isForServices ? 1 : 0);
            }
            if (updates.isForAIApps !== undefined) {
                setClauses.push('is_for_ai_apps = ?');
                values.push(updates.isForAIApps ? 1 : 0);
            }
            if (updates.displayOrder !== undefined) {
                setClauses.push('display_order = ?');
                values.push(updates.displayOrder);
            }
            if (setClauses.length === 0) {
                console.log(`DatabaseStorage: No valid updates provided`);
                rawDb.close();
                return null;
            }
            values.push(id);
            const updateResult = rawDb.prepare(`
        UPDATE categories 
        SET ${setClauses.join(', ')} 
        WHERE id = ?
      `).run(...values);
            if (updateResult.changes === 0) {
                console.log(`DatabaseStorage: No rows updated for id=${id}`);
                rawDb.close();
                return null;
            }
            const updatedCategory = rawDb.prepare(`
        SELECT id, name, icon, color, description,
               COALESCE(is_for_products, 1) as isForProducts,
               COALESCE(is_for_services, 0) as isForServices,
               COALESCE(is_for_ai_apps, 0) as isForAIApps,
               COALESCE(display_order, 0) as displayOrder
        FROM categories 
        WHERE id = ?
      `).get(id);
            rawDb.close();
            return updatedCategory;
        }
        catch (error) {
            console.error('DatabaseStorage: updateCategory failed:', error);
            return null;
        }
    }
    async deleteCategory(id) {
        await db.delete(categories).where(eq(categories.id, id));
        return true;
    }
    // Blog Posts
    async getBlogPosts() {
        return await db.select().from(blogPosts).orderBy(desc(blogPosts.publishedAt));
    }
    // Newsletter
    async subscribeToNewsletter(subscriber) {
        const [newSubscriber] = await db
            .insert(newsletterSubscribers)
            .values(subscriber)
            .returning();
        return newSubscriber;
    }
    async getNewsletterSubscribers() {
        return await db.select().from(newsletterSubscribers);
    }
    // Affiliate Networks
    async getAffiliateNetworks() {
        return await db.select().from(affiliateNetworks).orderBy(affiliateNetworks.name);
    }
    async getActiveAffiliateNetworks() {
        return await db.select().from(affiliateNetworks).where(eq(affiliateNetworks.isActive, true)).orderBy(affiliateNetworks.name);
    }
    async addAffiliateNetwork(network) {
        const [newNetwork] = await db
            .insert(affiliateNetworks)
            .values(network)
            .returning();
        return newNetwork;
    }
    async updateAffiliateNetwork(id, network) {
        const [updatedNetwork] = await db
            .update(affiliateNetworks)
            .set(network)
            .where(eq(affiliateNetworks.id, id))
            .returning();
        return updatedNetwork;
    }
    // Timer cleanup method
    async cleanupExpiredProducts() {
        try {
            return 0; // Simple cleanup for now
        }
        catch (error) {
            console.error('Error in cleanupExpiredProducts:', error);
            return 0;
        }
    }
    async cleanupExpiredBlogPosts() {
        try {
            return 0; // Simple cleanup for now
        }
        catch (error) {
            console.error('Error in cleanupExpiredBlogPosts:', error);
            return 0;
        }
    }
    // Admin Product Management
    async addProduct(product) {
        try {
            console.log('DatabaseStorage: Adding product with data:', product);
            // Validate input data
            validateProduct(product);
            // Normalize gender values for consistent storage
            const normalizeGender = (g) => {
                if (!g)
                    return null;
                const genderMap = {
                    'men': 'men',
                    'women': 'women',
                    'kids': 'kids',
                    'boys': 'boys',
                    'girls': 'girls'
                };
                return genderMap[g.toLowerCase()] || g.toLowerCase();
            };
            // Normalize numeric values
            const rating = typeof product.rating === 'string' ? parseFloat(product.rating) : product.rating;
            const reviewCount = typeof product.reviewCount === 'string' ? parseInt(product.reviewCount) : product.reviewCount;
            // Handle pricing logic differently for services vs products
            let price = 0;
            let originalPrice = null;
            let monthlyPrice = null;
            let yearlyPrice = null;
            let pricingType = null;
            let isFree = Boolean(product.isFree);
            // Debug: Check what values we have for isService and isAIApp
            console.log('DatabaseStorage: Checking product flags:', {
                isService: product.isService,
                isAIApp: product.isAIApp,
                isServiceBoolean: Boolean(product.isService),
                isAIAppBoolean: Boolean(product.isAIApp),
                conditionResult: Boolean(product.isService || product.isAIApp)
            });
            // Ensure proper boolean conversion for service/AI app flags
            const isServiceProduct = Boolean(product.isService);
            const isAIAppProduct = Boolean(product.isAIApp);
            if (isServiceProduct || isAIAppProduct) {
                // For services and AI Apps, handle pricing based on type and available fields
                pricingType = product.pricingType || 'one-time';
                monthlyPrice = product.monthlyPrice?.toString().trim() || null;
                yearlyPrice = product.yearlyPrice?.toString().trim() || null;
                console.log('Service/AI App pricing debug:', {
                    isService: isServiceProduct,
                    isAIApp: isAIAppProduct,
                    isFree,
                    pricingType,
                    monthlyPrice,
                    yearlyPrice,
                    regularPrice: product.price
                });
                // Determine pricing based on what's provided - prioritize isFree flag first
                if (isFree || pricingType === 'free') {
                    price = 0;
                    pricingType = 'free';
                    console.log('Setting as free service/AI app');
                }
                else if (pricingType === 'monthly' && monthlyPrice && monthlyPrice !== '0' && monthlyPrice !== '') {
                    // Monthly pricing provided
                    price = parseFloat(monthlyPrice.replace(/[^\d.]/g, '')) || 0;
                    pricingType = 'monthly';
                    console.log('Setting as monthly service/AI app:', price);
                }
                else if (pricingType === 'yearly' && yearlyPrice && yearlyPrice !== '0' && yearlyPrice !== '') {
                    // Yearly pricing provided
                    price = parseFloat(yearlyPrice.replace(/[^\d.]/g, '')) || 0;
                    pricingType = 'yearly';
                    console.log('Setting as yearly service/AI app:', price);
                }
                else if (pricingType === 'one-time' && product.price && product.price !== '0') {
                    // One-time pricing provided
                    price = typeof product.price === 'string' ? parseFloat(product.price.replace(/[^\d.]/g, '')) : product.price;
                    pricingType = 'one-time';
                    console.log('Setting as one-time service/AI app:', price);
                }
                else {
                    // Fallback - use whatever price is available
                    price = typeof product.price === 'string' ? parseFloat(product.price.replace(/[^\d.]/g, '')) : (product.price || 0);
                    console.log('Fallback pricing:', price, pricingType);
                }
                // Handle original price for services and AI Apps
                if (product.originalPrice) {
                    originalPrice = typeof product.originalPrice === 'string' ? parseFloat(product.originalPrice.replace(/[^\d.]/g, '')) : product.originalPrice;
                }
            }
            else {
                // For regular products, use standard pricing
                price = typeof product.price === 'string' ? parseFloat(product.price.replace(/[^\d.]/g, '')) : product.price;
                originalPrice = product.originalPrice ?
                    (typeof product.originalPrice === 'string' ? parseFloat(product.originalPrice.replace(/[^\d.]/g, '')) : product.originalPrice) : null;
            }
            // Handle timer logic and data transformation
            const now = new Date();
            const normalizedGender = normalizeGender(product.gender);
            // Debug pricing variables before productData construction
            console.log('DatabaseStorage: Final pricing variables before DB insert:', {
                pricingType,
                monthlyPrice,
                yearlyPrice,
                isFree,
                priceDescription: product.priceDescription?.trim() || null,
                isService: product.isService,
                isAIApp: product.isAIApp
            });
            // Compute storage-friendly price: keep blank when zero or invalid
            const priceForStore = (typeof price === 'number' && Number.isFinite(price) && price > 0)
                ? price.toString()
                : '';
            const productData = {
                name: product.name.trim(),
                description: product.description?.trim() || '',
                price: priceForStore,
                originalPrice: originalPrice ? originalPrice.toString() : null,
                currency: product.currency || 'INR',
                imageUrl: product.imageUrl?.trim() || '',
                affiliateUrl: product.affiliateUrl?.trim() || '',
                affiliateNetworkId: product.affiliateNetworkId || null,
                category: product.category || '',
                gender: normalizedGender,
                rating: (rating || 4.5).toString(),
                reviewCount: reviewCount || 100,
                discount: product.discount ? parseInt(product.discount.toString()) : null,
                isNew: Boolean(product.isNew),
                isFeatured: product.isFeatured !== undefined ? Boolean(product.isFeatured) : true,
                isService: Boolean(isServiceProduct),
                isAIApp: Boolean(isAIAppProduct),
                customFields: typeof product.customFields === 'object' ? JSON.stringify(product.customFields) : product.customFields,
                // Enhanced pricing fields for services and AI Apps
                pricingType: pricingType,
                monthlyPrice: monthlyPrice,
                yearlyPrice: yearlyPrice,
                isFree: isFree,
                priceDescription: product.priceDescription?.trim() || null,
                hasTimer: Boolean(product.hasTimer),
                timerDuration: product.hasTimer ? parseInt(product.timerDuration?.toString() || '24') : null,
                timerStartTime: product.hasTimer ? now : null,
                createdAt: now,
                // Display pages selection - convert array to JSON string for storage
                displayPages: product.displayPages ? JSON.stringify(product.displayPages) : JSON.stringify([])
            };
            console.log('DatabaseStorage: Final productData object:', productData);
            console.log('DatabaseStorage: Transformed product data with normalized gender:', productData);
            console.log(`Gender normalization: "${product.gender}" -> "${normalizedGender}"`);
            // Insert into unified_content table instead of products table
            const unifiedContentData = {
                title: product.name.trim(),
                description: product.description?.trim() || '',
                content: product.description?.trim() || '',
                content_type: 'product',
                source_platform: 'admin',
                source_id: null,
                media_urls: product.imageUrl?.trim() ? JSON.stringify([product.imageUrl.trim()]) : null,
                affiliate_urls: product.affiliateUrl?.trim() ? JSON.stringify([product.affiliateUrl.trim()]) : null,
                original_urls: null,
                tags: product.category ? JSON.stringify([product.category]) : null,
                category: product.category || '',
                engagement_metrics: JSON.stringify({
                    rating: (rating || 4.5),
                    reviewCount: reviewCount || 100,
                    discount: product.discount ? parseInt(product.discount.toString()) : null
                }),
                seo_title: product.name.trim(),
                seo_description: product.description?.trim() || '',
                seo_keywords: product.category || '',
                image_url: product.imageUrl?.trim() || '',
                status: 'published',
                visibility: 'public',
                scheduled_at: null,
                published_at: Math.floor(now.getTime() / 1000),
                expires_at: product.hasTimer ? Math.floor((now.getTime() + (parseInt(product.timerDuration?.toString() || '24') * 60 * 60 * 1000)) / 1000) : null,
                created_at: Math.floor(now.getTime() / 1000),
                updated_at: Math.floor(now.getTime() / 1000),
                metadata: JSON.stringify({
                    price: priceForStore,
                    originalPrice: originalPrice ? originalPrice.toString() : null,
                    currency: product.currency || 'INR',
                    gender: normalizedGender,
                    isNew: Boolean(product.isNew),
                    isFeatured: product.isFeatured !== undefined ? Boolean(product.isFeatured) : true,
                    isService: Boolean(isServiceProduct),
                    isAIApp: Boolean(isAIAppProduct),
                    customFields: typeof product.customFields === 'object' ? product.customFields : (product.customFields || {}),
                    pricingType: pricingType,
                    monthlyPrice: monthlyPrice,
                    yearlyPrice: yearlyPrice,
                    isFree: isFree,
                    priceDescription: product.priceDescription?.trim() || null,
                    hasTimer: Boolean(product.hasTimer),
                    timerDuration: product.hasTimer ? parseInt(product.timerDuration?.toString() || '24') : null,
                    timerStartTime: product.hasTimer ? now.toISOString() : null,
                    affiliateNetworkId: product.affiliateNetworkId || null
                }),
                processing_status: 'active',
                ai_generated: 0,
                display_pages: product.displayPages ? JSON.stringify(product.displayPages) : JSON.stringify([])
            };
            console.log('DatabaseStorage: Final unifiedContentData object:', unifiedContentData);
            // Derive content_type based on flags to ensure proper filtering in routes
            const derivedContentType = isServiceProduct ? 'service' : (isAIAppProduct ? 'ai-app' : 'product');
            // Helper to generate a simple, user-friendly category description when missing
            const generateCategoryDescription = (name, opts) => {
                const base = name.trim();
                if (!base)
                    return 'Explore products';
                if (opts.isService)
                    return `Professional services for ${base}`;
                if (opts.isAIApp)
                    return `AI apps and tools for ${base}`;
                return `Products and tools for ${base}`;
            };
            // Ensure category hierarchy exists and is active; upsert parent and optional child (subcategory)
            try {
                const parentName = (product.category || '').trim();
                const subcatName = (product.subcategory || '').trim();
                let parentId = null;
                if (parentName) {
                    const existingParent = this.sqliteDb.prepare(`
            SELECT id, is_for_products, is_for_services, is_for_ai_apps FROM categories WHERE name = ?
          `).get(parentName);
                    if (!existingParent) {
                        const parentDesc = generateCategoryDescription(parentName, { isService: Boolean(isServiceProduct), isAIApp: Boolean(isAIAppProduct) });
                        const insertParent = this.sqliteDb.prepare(`
              INSERT INTO categories (
                name, description, icon, color, display_order,
                is_for_products, is_for_services, is_for_ai_apps,
                is_active, parent_id
              ) VALUES (?, ?, 'mdi-tag', '#888888', 0, ?, ?, ?, 1, NULL)
            `).run(parentName, parentDesc, (isServiceProduct || isAIAppProduct) ? 0 : 1, isServiceProduct ? 1 : 0, isAIAppProduct ? 1 : 0);
                        parentId = Number(insertParent.lastInsertRowid);
                        console.log(`Upsert: created parent category "${parentName}" (id=${parentId}) and marked active.`);
                    }
                    else {
                        const setProducts = existingParent.is_for_products ? 1 : ((isServiceProduct || isAIAppProduct) ? 0 : 1);
                        const setServices = existingParent.is_for_services ? 1 : (isServiceProduct ? 1 : 0);
                        const setApps = existingParent.is_for_ai_apps ? 1 : (isAIAppProduct ? 1 : 0);
                        this.sqliteDb.prepare(`
              UPDATE categories 
              SET is_active = 1,
                  is_for_products = ?,
                  is_for_services = ?,
                  is_for_ai_apps = ?
              WHERE id = ?
            `).run(setProducts, setServices, setApps, existingParent.id);
                        parentId = Number(existingParent.id);
                        console.log(`Upsert: activated parent category "${parentName}" (id=${parentId}) and updated type flags.`);
                    }
                }
                if (subcatName) {
                    const existingChild = this.sqliteDb.prepare(`
            SELECT id, parent_id, is_for_products, is_for_services, is_for_ai_apps FROM categories WHERE name = ?
          `).get(subcatName);
                    if (!existingChild) {
                        const childDesc = generateCategoryDescription(subcatName, { isService: Boolean(isServiceProduct), isAIApp: Boolean(isAIAppProduct) });
                        const insertChild = this.sqliteDb.prepare(`
              INSERT INTO categories (
                name, description, icon, color, display_order,
                is_for_products, is_for_services, is_for_ai_apps,
                is_active, parent_id
              ) VALUES (?, ?, 'mdi-tag', '#888888', 0, ?, ?, ?, 1, ?)
            `).run(subcatName, childDesc, (isServiceProduct || isAIAppProduct) ? 0 : 1, isServiceProduct ? 1 : 0, isAIAppProduct ? 1 : 0, parentId);
                        console.log(`Upsert: created subcategory "${subcatName}" (parent_id=${parentId}) and marked active.`);
                    }
                    else {
                        const setProducts = existingChild.is_for_products ? 1 : ((isServiceProduct || isAIAppProduct) ? 0 : 1);
                        const setServices = existingChild.is_for_services ? 1 : (isServiceProduct ? 1 : 0);
                        const setApps = existingChild.is_for_ai_apps ? 1 : (isAIAppProduct ? 1 : 0);
                        this.sqliteDb.prepare(`
              UPDATE categories 
              SET is_active = 1,
                  is_for_products = ?,
                  is_for_services = ?,
                  is_for_ai_apps = ?,
                  parent_id = COALESCE(parent_id, ?)
              WHERE id = ?
            `).run(setProducts, setServices, setApps, parentId, existingChild.id);
                        console.log(`Upsert: activated subcategory "${subcatName}" and linked to parent_id=${parentId}.`);
                    }
                }
            }
            catch (catErr) {
                console.error('Category upsert error (non-blocking):', catErr);
            }
            // Use raw SQL to insert into unified_content table - matching actual column names
            // Determine discount percentage for unified_content (prefer explicit value, fallback to computed)
            const discountPercentageForUnified = (product.discount !== undefined && product.discount !== null && product.discount !== '')
                ? parseInt(product.discount.toString())
                : (originalPrice && price && originalPrice > price
                    ? Math.round(((originalPrice - price) / originalPrice) * 100)
                    : null);
            const result = this.sqliteDb.prepare(`
        INSERT INTO unified_content (
          title, description, content_type, source_platform,
          affiliate_url, category, subcategory, status, visibility, page_type,
          created_at, updated_at, processing_status, display_pages,
          price, original_price, discount, image_url, affiliate_urls,
          is_featured, is_service, is_ai_app, is_active,
          pricing_type, monthly_price, yearly_price, is_free, price_description
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(unifiedContentData.title, unifiedContentData.description, derivedContentType, unifiedContentData.source_platform, unifiedContentData.affiliate_urls ? JSON.parse(unifiedContentData.affiliate_urls)[0] : null, unifiedContentData.category, (product.subcategory ? String(product.subcategory).trim() : null), 'active', unifiedContentData.visibility, 'product', unifiedContentData.created_at, unifiedContentData.updated_at, unifiedContentData.processing_status, unifiedContentData.display_pages, priceForStore, originalPrice ? originalPrice.toString() : null, discountPercentageForUnified, unifiedContentData.image_url, unifiedContentData.affiliate_urls, product.isFeatured !== undefined ? (product.isFeatured ? 1 : 0) : 0, isServiceProduct ? 1 : 0, isAIAppProduct ? 1 : 0, 1, pricingType || 'one-time', monthlyPrice || null, yearlyPrice || null, isFree ? 1 : 0, product.priceDescription || null);
            // Create a product-like object to return
            const newProduct = {
                id: result.lastInsertRowid,
                name: product.name.trim(),
                description: product.description?.trim() || '',
                price: priceForStore,
                originalPrice: originalPrice ? originalPrice.toString() : null,
                currency: product.currency || 'INR',
                imageUrl: product.imageUrl?.trim() || '',
                affiliateUrl: product.affiliateUrl?.trim() || '',
                category: product.category || '',
                rating: (rating || 4.5).toString(),
                reviewCount: reviewCount || 100,
                discount: product.discount ? parseInt(product.discount.toString()) : null,
                isNew: Boolean(product.isNew),
                isFeatured: product.isFeatured !== undefined ? Boolean(product.isFeatured) : true,
                isService: Boolean(isServiceProduct),
                isAIApp: Boolean(isAIAppProduct),
                createdAt: now
            };
            // If product is marked as featured, also add it to the featured_products table
            if (newProduct.isFeatured) {
                try {
                    console.log('⭐ Adding featured product to featured_products table...');
                    // Calculate discount percentage if both prices are available
                    let discountPercentage = null;
                    if (originalPrice && price && originalPrice > price) {
                        discountPercentage = Math.round(((originalPrice - price) / originalPrice) * 100);
                    }
                    const featuredProductData = {
                        name: newProduct.name,
                        description: newProduct.description,
                        price: newProduct.price,
                        original_price: newProduct.originalPrice,
                        currency: newProduct.currency,
                        image_url: newProduct.imageUrl,
                        affiliate_url: newProduct.affiliateUrl,
                        category: newProduct.category,
                        rating: newProduct.rating,
                        review_count: newProduct.reviewCount,
                        discount: discountPercentage,
                        is_featured: 1,
                        is_new: newProduct.isNew ? 1 : 0,
                        is_active: 1,
                        display_order: 0,
                        has_timer: product.hasTimer ? 1 : 0,
                        timer_duration: product.hasTimer ? parseInt(product.timerDuration?.toString() || '24') : null,
                        timer_start_time: product.hasTimer ? Math.floor(now.getTime() / 1000) : null,
                        affiliate_network: 'Manual',
                        source: 'admin',
                        content_type: isServiceProduct ? 'service' : (isAIAppProduct ? 'aiapp' : 'product'),
                        created_at: Math.floor(now.getTime() / 1000),
                        updated_at: Math.floor(now.getTime() / 1000)
                    };
                    // Insert into featured_products table
                    const featuredInsertResult = this.sqliteDb.prepare(`
            INSERT INTO featured_products (
              name, description, price, original_price, currency, image_url, affiliate_url,
              category, rating, review_count, discount, is_featured, is_new, is_active,
              display_order, has_timer, timer_duration, timer_start_time, affiliate_network,
              source, content_type, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
          `).run(featuredProductData.name, featuredProductData.description, featuredProductData.price, featuredProductData.original_price, featuredProductData.currency, featuredProductData.image_url, featuredProductData.affiliate_url, featuredProductData.category, featuredProductData.rating, featuredProductData.review_count, featuredProductData.discount, featuredProductData.is_featured, featuredProductData.is_new, featuredProductData.is_active, featuredProductData.display_order, featuredProductData.has_timer, featuredProductData.timer_duration, featuredProductData.timer_start_time, featuredProductData.affiliate_network, featuredProductData.source, featuredProductData.content_type, featuredProductData.created_at, featuredProductData.updated_at);
                    console.log(`✅ Featured product added to featured_products table with ID: ${featuredInsertResult.lastInsertRowid}`);
                }
                catch (featuredError) {
                    console.error('❌ Error adding to featured_products table:', featuredError);
                    // Don't throw error here - the main product was still added successfully
                }
            }
            console.log('DatabaseStorage: Product added successfully:', newProduct);
            return newProduct;
        }
        catch (error) {
            console.error('DatabaseStorage: Error adding product:', error);
            throw new Error(`Failed to add product: ${error?.message || 'Unknown error'}`);
        }
    }
    async deleteProduct(id) {
        await db.delete(products).where(eq(products.id, id));
        return true;
    }
    async updateProduct(id, updates) {
        // First try updating the legacy products table via ORM
        const [updatedProduct] = await db
            .update(products)
            .set(updates)
            .where(eq(products.id, id))
            .returning();
        if (updatedProduct) {
            return updatedProduct;
        }
        // Fallback: update unified_content where admin add operations store records
        // Map incoming update fields to unified_content columns
        const fieldMap = {
            name: 'title',
            description: 'description',
            price: 'price',
            originalPrice: 'original_price',
            currency: 'currency',
            imageUrl: 'image_url',
            affiliateUrl: 'affiliate_url',
            category: 'category',
            rating: 'rating',
            reviewCount: 'review_count',
            discount: 'discount',
            isFeatured: 'is_featured',
            isService: 'is_service',
            isAIApp: 'is_ai_app',
            pricingType: 'pricing_type',
            monthlyPrice: 'monthly_price',
            yearlyPrice: 'yearly_price',
            isFree: 'is_free',
            priceDescription: 'price_description',
            displayPages: 'display_pages',
        };
        const setClauses = [];
        const params = [];
        // Build dynamic SET clause for only provided fields
        for (const key of Object.keys(fieldMap)) {
            if (updates[key] !== undefined) {
                let value = updates[key];
                // Serialize displayPages to JSON string for unified_content
                if (key === 'displayPages') {
                    value = Array.isArray(value) ? JSON.stringify(value) : JSON.stringify([]);
                }
                // Normalize booleans to integers for unified_content flags
                if (key === 'isFeatured' || key === 'isService' || key === 'isAIApp' || key === 'isFree') {
                    value = value ? 1 : 0;
                }
                setClauses.push(`${fieldMap[key]} = ?`);
                params.push(value);
            }
        }
        // Always bump the updated_at timestamp if we're touching unified_content
        if (setClauses.length > 0) {
            const nowEpoch = Math.floor(Date.now() / 1000);
            setClauses.push(`updated_at = ?`);
            params.push(nowEpoch);
            const sql = `UPDATE unified_content SET ${setClauses.join(', ')} WHERE id = ?`;
            params.push(id);
            try {
                const result = this.sqliteDb.prepare(sql).run(...params);
                if (result.changes > 0) {
                    const row = this.sqliteDb.prepare(`SELECT * FROM unified_content WHERE id = ?`).get(id);
                    if (row) {
                        // Return a product-like object for consistency
                        const mapped = {
                            id: row.id,
                            name: row.title,
                            description: row.description,
                            price: row.price,
                            originalPrice: row.original_price,
                            currency: row.currency || 'INR',
                            imageUrl: row.image_url,
                            affiliateUrl: row.affiliate_url,
                            category: row.category,
                            rating: row.rating,
                            reviewCount: row.review_count,
                            discount: row.discount,
                            isFeatured: !!row.is_featured,
                            isService: !!row.is_service,
                            isAIApp: !!row.is_ai_app,
                        };
                        return mapped;
                    }
                }
            }
            catch (e) {
                console.error('❌ DatabaseStorage: unified_content update failed:', e);
            }
        }
        // Nothing updated
        return null;
    }
    // Blog Management
    async addBlogPost(blogPost) {
        const blogPostData = {
            ...blogPost,
            hasTimer: blogPost.hasTimer || false,
            timerDuration: blogPost.hasTimer && blogPost.timerDuration ? parseInt(blogPost.timerDuration.toString()) : null,
            timerStartTime: blogPost.hasTimer ? new Date() : null,
            publishedAt: new Date(blogPost.publishedAt || new Date()),
            slug: blogPost.slug || blogPost.title.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
            excerpt: blogPost.excerpt || '',
            readTime: blogPost.readTime || '5 min read',
            imageUrl: blogPost.imageUrl || '',
            pdfUrl: blogPost.pdfUrl || null,
            category: blogPost.category || 'General',
            title: blogPost.title || 'Untitled',
            content: blogPost.content || '',
        };
        const [newBlogPost] = await db
            .insert(blogPosts)
            .values(blogPostData)
            .returning();
        return newBlogPost;
    }
    async deleteBlogPost(id) {
        await db.delete(blogPosts).where(eq(blogPosts.id, id));
        return true;
    }
    async updateBlogPost(id, updates) {
        const [updatedBlogPost] = await db
            .update(blogPosts)
            .set(updates)
            .where(eq(blogPosts.id, id))
            .returning();
        return updatedBlogPost || null;
    }
    async getAnnouncements() {
        return await db.select().from(announcements).orderBy(desc(announcements.createdAt));
    }
    async createAnnouncement(announcement) {
        if (announcement.isActive) {
            await db.update(announcements).set({ isActive: false });
        }
        const [newAnnouncement] = await db.insert(announcements).values({
            ...announcement,
            createdAt: new Date()
        }).returning();
        return newAnnouncement;
    }
    async updateAnnouncement(id, updates) {
        if (updates.isActive) {
            await db.update(announcements)
                .set({ isActive: false })
                .where(ne(announcements.id, id));
        }
        const [updatedAnnouncement] = await db.update(announcements)
            .set(updates)
            .where(eq(announcements.id, id))
            .returning();
        return updatedAnnouncement || null;
    }
    async deleteAnnouncement(id) {
        await db.delete(announcements).where(eq(announcements.id, id));
        return true;
    }
    // Admin User Management
    async getAdminByEmail(email) {
        const [admin] = await db.select().from(adminUsers).where(eq(adminUsers.email, email));
        return admin || undefined;
    }
    async getAdminByUsername(username) {
        const [admin] = await db.select().from(adminUsers).where(eq(adminUsers.username, username));
        return admin || undefined;
    }
    async getAdminById(id) {
        const [admin] = await db.select().from(adminUsers).where(eq(adminUsers.id, id));
        return admin || undefined;
    }
    async createAdmin(admin) {
        const [newAdmin] = await db
            .insert(adminUsers)
            .values(admin)
            .returning();
        return newAdmin;
    }
    async updateAdminPassword(id, passwordHash) {
        await db
            .update(adminUsers)
            .set({ passwordHash })
            .where(eq(adminUsers.id, id));
        return true;
    }
    async setResetToken(email, token, expiry) {
        await db
            .update(adminUsers)
            .set({ resetToken: token, resetTokenExpiry: expiry })
            .where(eq(adminUsers.email, email));
        return true;
    }
    async validateResetToken(token) {
        const [admin] = await db
            .select()
            .from(adminUsers)
            .where(eq(adminUsers.resetToken, token));
        if (!admin || !admin.resetTokenExpiry || admin.resetTokenExpiry < new Date()) {
            return undefined;
        }
        return admin;
    }
    async clearResetToken(id) {
        await db
            .update(adminUsers)
            .set({ resetToken: null, resetTokenExpiry: null })
            .where(eq(adminUsers.id, id));
        return true;
    }
    async updateLastLogin(id) {
        await db
            .update(adminUsers)
            .set({ lastLogin: new Date() })
            .where(eq(adminUsers.id, id));
        return true;
    }
    // Video Content Management
    async getVideoContent() {
        await this.cleanupExpiredVideoContent();
        return await db.select().from(videoContent).orderBy(desc(videoContent.createdAt));
    }
    async addVideoContent(videoContentData) {
        const videoData = {
            ...videoContentData,
            hasTimer: videoContentData.hasTimer || false,
            timerDuration: videoContentData.hasTimer && videoContentData.timerDuration ? parseInt(videoContentData.timerDuration.toString()) : null,
            timerStartTime: videoContentData.hasTimer ? new Date() : null,
            tags: Array.isArray(videoContentData.tags) ? JSON.stringify(videoContentData.tags) : videoContentData.tags,
            pages: Array.isArray(videoContentData.pages) ? JSON.stringify(videoContentData.pages) : (videoContentData.pages || '[]'),
            showOnHomepage: videoContentData.showOnHomepage !== undefined ? videoContentData.showOnHomepage : true,
            ctaText: videoContentData.ctaText || null,
            ctaUrl: videoContentData.ctaUrl || null,
            createdAt: new Date(),
        };
        const [newVideoContent] = await db
            .insert(videoContent)
            .values(videoData)
            .returning();
        return newVideoContent;
    }
    async deleteVideoContent(id) {
        await db.delete(videoContent).where(eq(videoContent.id, id));
        return true;
    }
    async deleteAllVideoContent() {
        try {
            // First get the count of videos to be deleted
            const allVideos = await db.select().from(videoContent);
            const count = allVideos.length;
            // Delete all video content
            await db.delete(videoContent);
            return count;
        }
        catch (error) {
            console.error('Error deleting all video content:', error);
            throw error;
        }
    }
    async updateVideoContent(id, updates) {
        const [updatedVideoContent] = await db
            .update(videoContent)
            .set(updates)
            .where(eq(videoContent.id, id))
            .returning();
        return updatedVideoContent || null;
    }
    async cleanupExpiredVideoContent() {
        try {
            return 0; // Simple cleanup for now
        }
        catch (error) {
            console.error('Error in cleanupExpiredVideoContent:', error);
            return 0;
        }
    }
    // Canva Automation Methods
    async getCanvaSettings() {
        try {
            // Ensure Canva tables exist before trying to query
            await this.ensureCanvaTablesExist();
            const [settings] = await db.select().from(canvaSettings).where(eq(canvaSettings.id, 1));
            return settings || null;
        }
        catch (error) {
            console.error('Error getting Canva settings:', error);
            return null;
        }
    }
    async updateCanvaSettings(settings) {
        try {
            // Ensure Canva tables exist before trying to update
            await this.ensureCanvaTablesExist();
            // First try to update existing settings
            const [updated] = await db
                .update(canvaSettings)
                .set({ ...settings, updatedAt: new Date() })
                .where(eq(canvaSettings.id, 1))
                .returning();
            if (updated) {
                return updated;
            }
            // If no existing settings, create new ones
            const [newSettings] = await db
                .insert(canvaSettings)
                .values({
                id: 1,
                ...settings,
                createdAt: new Date(),
                updatedAt: new Date()
            })
                .returning();
            return newSettings;
        }
        catch (error) {
            console.error('Error updating Canva settings:', error);
            throw new Error('Failed to update Canva settings');
        }
    }
    // Helper method to ensure Canva tables exist
    async ensureCanvaTablesExist() {
        try {
            const Database = (await import('better-sqlite3')).default;
            const dbFile = path.join(__dirname, '..', 'database.sqlite');
            const rawDb = new Database(dbFile);
            // Create canva_settings table if it doesn't exist - matching Drizzle schema exactly
            rawDb.exec(`
        CREATE TABLE IF NOT EXISTS canva_settings (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          is_enabled INTEGER DEFAULT 0,
          api_key TEXT,
          api_secret TEXT,
          default_template_id TEXT,
          auto_generate_captions INTEGER DEFAULT 1,
          auto_generate_hashtags INTEGER DEFAULT 1,
          default_title TEXT,
          default_caption TEXT,
          default_hashtags TEXT,
          platforms TEXT DEFAULT '[]',
          schedule_type TEXT DEFAULT 'immediate',
          schedule_delay_minutes INTEGER DEFAULT 0,
          created_at INTEGER DEFAULT (strftime('%s', 'now')),
          updated_at INTEGER DEFAULT (strftime('%s', 'now'))
        )
      `);
            // Create canva_posts table if it doesn't exist - matching Drizzle schema exactly
            rawDb.exec(`
        CREATE TABLE IF NOT EXISTS canva_posts (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          content_type TEXT NOT NULL,
          content_id INTEGER NOT NULL,
          design_id TEXT,
          template_id TEXT,
          caption TEXT,
          hashtags TEXT,
          platforms TEXT,
          post_urls TEXT,
          status TEXT DEFAULT 'pending',
          scheduled_at INTEGER,
          posted_at INTEGER,
          expires_at INTEGER,
          created_at INTEGER DEFAULT (strftime('%s', 'now')),
          updated_at INTEGER DEFAULT (strftime('%s', 'now'))
        )
      `);
            // Create canva_templates table if it doesn't exist - matching Drizzle schema exactly
            rawDb.exec(`
        CREATE TABLE IF NOT EXISTS canva_templates (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          template_id TEXT NOT NULL UNIQUE,
          name TEXT NOT NULL,
          type TEXT NOT NULL,
          category TEXT,
          thumbnail_url TEXT,
          is_active INTEGER DEFAULT 1,
          created_at INTEGER DEFAULT (strftime('%s', 'now'))
        )
      `);
            // Check if default settings exist, if not create them
            const existingSettings = rawDb.prepare('SELECT COUNT(*) as count FROM canva_settings').get();
            if (existingSettings.count === 0) {
                rawDb.prepare(`
          INSERT INTO canva_settings (
            is_enabled, 
            auto_generate_captions, 
            auto_generate_hashtags,
            default_title,
            default_caption,
            default_hashtags,
            platforms, 
            schedule_type, 
            schedule_delay_minutes,
            created_at,
            updated_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `).run(0, // is_enabled = false initially
                1, // auto_generate_captions = true
                1, // auto_generate_hashtags = true
                'Deal Amazing {category} Deal: {title}', // default_title
                'Deal Amazing {category} Alert! Special {title} Price Price: ₹{price} Link Get the best deals at PickNTrust!', '#PickNTrust #Deals #Shopping #BestPrice #Sale #Discount #OnlineShopping #India', JSON.stringify(['instagram', 'facebook']), // default platforms
                'immediate', 0, Math.floor(Date.now() / 1000), // created_at timestamp
                Math.floor(Date.now() / 1000) // updated_at timestamp
                );
                console.log('Success Created default Canva settings');
            }
            rawDb.close();
            console.log('Success Canva tables ensured to exist');
        }
        catch (error) {
            console.error('Error ensuring Canva tables exist:', error);
            // Don't throw here, let the main method handle the error
        }
    }
    async getCanvaPosts() {
        try {
            return await db.select().from(canvaPosts).orderBy(desc(canvaPosts.createdAt));
        }
        catch (error) {
            console.error('Error getting Canva posts:', error);
            return [];
        }
    }
    async addCanvaPost(post) {
        try {
            const [newPost] = await db
                .insert(canvaPosts)
                .values({ ...post, createdAt: new Date(), updatedAt: new Date() })
                .returning();
            return newPost;
        }
        catch (error) {
            console.error('Error adding Canva post:', error);
            throw new Error('Failed to add Canva post');
        }
    }
    async updateCanvaPost(id, updates) {
        try {
            const [updated] = await db
                .update(canvaPosts)
                .set({ ...updates, updatedAt: new Date() })
                .where(eq(canvaPosts.id, id))
                .returning();
            return updated || null;
        }
        catch (error) {
            console.error('Error updating Canva post:', error);
            return null;
        }
    }
    async deleteCanvaPost(id) {
        try {
            await db.delete(canvaPosts).where(eq(canvaPosts.id, id));
            return true;
        }
        catch (error) {
            console.error('Error deleting Canva post:', error);
            return false;
        }
    }
    async getCanvaTemplates() {
        try {
            return await db.select().from(canvaTemplates).where(eq(canvaTemplates.isActive, true)).orderBy(canvaTemplates.name);
        }
        catch (error) {
            console.error('Error getting Canva templates:', error);
            return [];
        }
    }
    async addCanvaTemplate(template) {
        try {
            const [newTemplate] = await db
                .insert(canvaTemplates)
                .values({ ...template, createdAt: new Date() })
                .returning();
            return newTemplate;
        }
        catch (error) {
            console.error('Error adding Canva template:', error);
            throw new Error('Failed to add Canva template');
        }
    }
    async updateCanvaTemplate(id, updates) {
        try {
            const [updated] = await db
                .update(canvaTemplates)
                .set(updates)
                .where(eq(canvaTemplates.id, id))
                .returning();
            return updated || null;
        }
        catch (error) {
            console.error('Error updating Canva template:', error);
            return null;
        }
    }
    async deleteCanvaTemplate(id) {
        try {
            await db.delete(canvaTemplates).where(eq(canvaTemplates.id, id));
            return true;
        }
        catch (error) {
            console.error('Error deleting Canva template:', error);
            return false;
        }
    }
    // Custom Platform Management Methods
    customPlatformsFile = 'custom-platforms.json';
    async getCustomPlatforms() {
        try {
            if (fs.existsSync(this.customPlatformsFile)) {
                const data = fs.readFileSync(this.customPlatformsFile, 'utf8');
                return JSON.parse(data);
            }
            return [];
        }
        catch (error) {
            console.error('Error getting custom platforms:', error);
            return [];
        }
    }
    async addCustomPlatform(platform) {
        try {
            const platforms = await this.getCustomPlatforms();
            platforms.push(platform);
            fs.writeFileSync(this.customPlatformsFile, JSON.stringify(platforms, null, 2));
            return platform;
        }
        catch (error) {
            console.error('Error adding custom platform:', error);
            throw new Error('Failed to add custom platform');
        }
    }
    async removeCustomPlatform(id) {
        try {
            const platforms = await this.getCustomPlatforms();
            const filteredPlatforms = platforms.filter(p => p.id !== id);
            fs.writeFileSync(this.customPlatformsFile, JSON.stringify(filteredPlatforms, null, 2));
            return true;
        }
        catch (error) {
            console.error('Error removing custom platform:', error);
            return false;
        }
    }
    async getCustomPlatform(id) {
        try {
            const platforms = await this.getCustomPlatforms();
            return platforms.find(p => p.id === id) || null;
        }
        catch (error) {
            console.error('Error getting custom platform:', error);
            return null;
        }
    }
    async updateCustomPlatform(id, updates) {
        try {
            const platforms = await this.getCustomPlatforms();
            const index = platforms.findIndex(p => p.id === id);
            if (index !== -1) {
                platforms[index] = { ...platforms[index], ...updates };
                fs.writeFileSync(this.customPlatformsFile, JSON.stringify(platforms, null, 2));
                return platforms[index];
            }
            return null;
        }
        catch (error) {
            console.error('Error updating custom platform:', error);
            return null;
        }
    }
}
export const storage = new DatabaseStorage();
