import TelegramBot from 'node-telegram-bot-api';
import { loadEnv } from './config/env-loader.js';
// Ensure environment variables are loaded in any execution context
loadEnv();
// import { CHANNEL_CONFIGS } from './config/channels.js'; // This file doesn't exist - using inline config
// import { convertUrls } from './services/affiliate-service.js'; // This file doesn't exist - using inline function
// import { extractProductInfo } from './services/url-processing-service.js'; // This file doesn't exist - using inline function
// import { saveProductToDatabase } from './services/database-service.js'; // This file doesn't exist - using inline function
// import { extractImageUrl } from './services/image-service.js'; // This file doesn't exist - using inline function
import { urlProcessingService } from './url-processing-service.js';
import Database from 'better-sqlite3';
import path from 'path';
import { fileURLToPath } from 'url';
import { categorizeForAutomation } from './enhanced-smart-categorization.js';
import { travelPicksBot } from './travel-picks-bot.js';
import { getDatabasePath } from './config/database.js';
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
// Admin alert chat configuration (set one of these in env)
// Prefer a private admin chat/channel to avoid spamming public channels
const ALERT_CHAT_ID = process.env.BOT_ALERT_CHAT_ID || process.env.MASTER_ADMIN_CHAT_ID || '';
// Silent mode: when enabled, the bot will NOT send any messages
// back to Telegram (no replies, no channel posts, no admin alerts).
// Set via env: BOT_SILENT=true|1|yes
const BOT_SILENT = ['1', 'true', 'yes'].includes(String(process.env.BOT_SILENT || '').toLowerCase());
// Singleton pattern to prevent multiple bot instances
class TelegramBotManager {
    static instance = null;
    bot = null;
    isInitialized = false;
    constructor() { }
    static getInstance() {
        if (!TelegramBotManager.instance) {
            TelegramBotManager.instance = new TelegramBotManager();
        }
        return TelegramBotManager.instance;
    }
    async processChannelPost(msg) {
        return processMessage(msg);
    }
    async processMessage(msg) {
        return processMessage(msg);
    }
    getBot() {
        return this.bot;
    }
    // Lightweight status accessor to avoid exposing internals
    getStatus() {
        const hasToken = Boolean(process.env.MASTER_BOT_TOKEN || process.env.TELEGRAM_BOT_TOKEN);
        const env = process.env.NODE_ENV || 'unknown';
        return { initialized: this.isInitialized, hasToken, env };
    }
    async initializeBot() {
        if (this.isInitialized) {
            console.log('🤖 Bot already initialized, skipping...');
            return;
        }
        // Initialize based on presence of a bot token; optional disable via DISABLE_TELEGRAM_BOT
        if (process.env.DISABLE_TELEGRAM_BOT === 'true') {
            console.log('⏸️ Telegram bot disabled via DISABLE_TELEGRAM_BOT flag');
            return;
        }
        console.log('🤖 Initializing Telegram bot (webhook-only mode)...');
        // Bot configuration - prefer MASTER_BOT_TOKEN, fallback to TELEGRAM_BOT_TOKEN
        const BOT_TOKEN = process.env.MASTER_BOT_TOKEN || process.env.TELEGRAM_BOT_TOKEN;
        if (!BOT_TOKEN) {
            console.error('❌ MASTER_BOT_TOKEN/TELEGRAM_BOT_TOKEN not found in environment variables');
            return;
        }
        try {
            // Stop any existing bot instance
            if (this.bot) {
                console.log('🛑 Stopping existing bot instance...');
                try {
                    await this.bot.stopPolling();
                }
                catch (error) {
                    console.log('⚠️ Error stopping polling (may not be running):', error.message);
                }
                this.bot = null;
            }
            // Initialize bot in webhook mode (no polling)
            this.bot = new TelegramBot(BOT_TOKEN, {
                polling: false,
                webHook: false
            });
            console.log('✅ Telegram bot initialized successfully in webhook mode (polling disabled)');
            this.isInitialized = true;
            // Ensure master webhook is configured
            try {
                const baseUrl = process.env.PUBLIC_BASE_URL || 'https://pickntrust.com';
                const webhookUrl = `${baseUrl}/webhook/master/${BOT_TOKEN}`;
                console.log(`🔗 Ensuring webhook is set: ${webhookUrl}`);
                // Clear any existing webhook to avoid conflicts
                await this.bot.deleteWebHook();
                // Set webhook to master endpoint
                await this.bot.setWebHook(webhookUrl, {
                    allowed_updates: ['message', 'channel_post', 'edited_channel_post']
                });
                // Verify webhook status
                const info = await this.bot.getWebHookInfo();
                console.log('📊 Webhook info', {
                    url: info.url,
                    pending_update_count: info.pending_update_count,
                    has_custom_certificate: info.has_custom_certificate,
                    max_connections: info.max_connections,
                });
            }
            catch (err) {
                console.warn('⚠️ Failed to configure master webhook:', err?.message || err);
            }
            // Setup event handlers
            this.setupEventHandlers();
            // Initialize travel bot
            await travelPicksBot.initialize();
            // Send initialization alert to admin chat if configured
            try {
                if (ALERT_CHAT_ID) {
                    const me = await this.bot.getMe();
                    const baseUrl = process.env.PUBLIC_BASE_URL || 'https://pickntrust.com';
                    const info = await this.bot.getWebHookInfo();
                    const msg = `✅ <b>Bot Initialized</b>\n` +
                        `• Bot: <code>${me.username}</code> (ID: ${me.id})\n` +
                        `• Mode: webhook-only\n` +
                        `• Webhook: <code>${info.url || baseUrl}</code>\n` +
                        `• Pending: ${info.pending_update_count || 0}\n` +
                        `• Env: <code>${process.env.NODE_ENV || 'unknown'}</code>`;
                    if (!BOT_SILENT) {
                        await this.bot.sendMessage(ALERT_CHAT_ID, msg, { parse_mode: 'HTML' });
                    }
                    else {
                        console.log('🔕 BOT_SILENT enabled: Skipping init alert');
                    }
                }
                else {
                    console.log('ℹ️ No ALERT_CHAT_ID configured; skipping init alert');
                }
            }
            catch (alertErr) {
                console.warn('⚠️ Failed to send initialization alert:', alertErr?.message || alertErr);
            }
            // Setup graceful shutdown
            this.setupGracefulShutdown();
        }
        catch (error) {
            console.error('❌ Failed to initialize Telegram bot:', error);
            this.isInitialized = false;
        }
    }
    setupEventHandlers() {
        if (!this.bot)
            return;
        // Handle channel posts (messages sent to channels)
        this.bot.on('channel_post', (msg) => {
            console.log('📨 Received channel post:', {
                chatId: Number(msg.chat.id),
                chatTitle: msg.chat.title,
                messageId: Number(msg.message_id),
                text: msg.text?.substring(0, 100) + '...'
            });
            processMessage(msg);
        });
        // Handle regular messages (for testing in private chats)
        this.bot.on('message', (msg) => {
            console.log('📩 Received message:', {
                chatId: Number(msg.chat.id),
                chatTitle: msg.chat.title || 'Private Chat',
                messageId: Number(msg.message_id),
                text: msg.text?.substring(0, 100) + '...'
            });
            processMessage(msg);
        });
        // Error handling
        this.bot.on('error', (error) => {
            console.error('Telegram bot error:', error);
        });
        console.log('✅ Event handlers set up successfully');
        console.log('Monitoring channels: [Channel configs will be loaded after initialization]');
    }
    setupGracefulShutdown() {
        const cleanup = async () => {
            // Stop travel bot first
            await travelPicksBot.stop();
            if (this.bot) {
                console.log('🛑 Shutting down Telegram bot...');
                try {
                    await this.bot.stopPolling();
                    console.log('✅ Bot stopped successfully');
                }
                catch (error) {
                    console.error('❌ Error stopping bot:', error);
                }
                this.bot = null;
                this.isInitialized = false;
            }
        };
        process.on('SIGINT', cleanup);
        process.on('SIGTERM', cleanup);
        process.on('exit', cleanup);
    }
    async stopBot() {
        // Stop travel bot first
        await travelPicksBot.stop();
        if (this.bot) {
            console.log('🛑 Stopping bot...');
            await this.bot.stopPolling();
            this.bot = null;
            this.isInitialized = false;
        }
    }
}
// Initialize singleton instance
const botManager = TelegramBotManager.getInstance();
// Initialize bot (guarded so failures never impact website/server startup)
try {
    await botManager.initializeBot();
}
catch (err) {
    console.error('⚠️ Bot initialization encountered an error but will not affect website:', err);
}
// Get bot instance
const bot = botManager.getBot();
// Function to send notifications/posts to Telegram channels
const sendTelegramNotification = async (channelId, message, options = {}) => {
    const currentBot = botManager.getBot();
    if (!currentBot) {
        console.error('❌ Bot not initialized');
        return false;
    }
    try {
        if (BOT_SILENT) {
            console.log('🔕 BOT_SILENT enabled: Skipping sending channel message');
            return false;
        }
        console.log(`📤 Sending message to channel ${channelId}...`);
        const result = await currentBot.sendMessage(channelId, message, {
            parse_mode: 'HTML',
            disable_web_page_preview: false,
            ...options
        });
        console.log(`✅ Message sent successfully to ${channelId}:`, result.message_id);
        return result;
    }
    catch (error) {
        console.error(`❌ Failed to send message to ${channelId}:`, error);
        return false;
    }
};
// Internal helper to send admin alerts safely
async function notifyAdmin(message, options = {}) {
    try {
        if (BOT_SILENT) {
            console.log('🔕 BOT_SILENT enabled: Skipping admin notification:', message);
            return false;
        }
        if (!ALERT_CHAT_ID) {
            console.log('ℹ️ ALERT_CHAT_ID not set; admin alert:', message);
            return false;
        }
        const currentBot = botManager.getBot();
        if (!currentBot) {
            console.error('❌ Bot not initialized; cannot send admin alert');
            return false;
        }
        await currentBot.sendMessage(ALERT_CHAT_ID, message, { parse_mode: 'HTML', ...options });
        return true;
    }
    catch (err) {
        console.warn('⚠️ Failed to send admin alert:', err?.message || err);
        return false;
    }
}
// Channel mappings with their respective configurations
const CHANNEL_CONFIGS = {
    '-1002955338551': {
        pageName: 'Prime Picks',
        affiliateTag: 'tag=pickntrust03-21',
        platform: 'amazon',
        pageSlug: 'prime-picks'
    },
    '-1002982344997': {
        pageName: 'Cue Picks',
        affiliateTag: 'https://linksredirect.com/?cid=243942&source=linkkit&url=%7B%7BURL_ENC%7D%7D',
        platform: 'cuelinks',
        pageSlug: 'cue-picks'
    },
    '-1003017626269': {
        pageName: 'Value Picks',
        affiliateTag: '', // Will be handled by earnkaro
        platform: 'earnkaro',
        pageSlug: 'value-picks'
    },
    '-1002981205504': {
        pageName: 'Click Picks',
        affiliateTag: '',
        platform: 'multiple',
        platforms: ['cuelinks', 'inrdeals', 'earnkaro'],
        pageSlug: 'click-picks'
    },
    '-1002902496654': {
        pageName: 'Global Picks',
        affiliateTag: '',
        platform: 'multiple',
        platforms: ['cuelinks', 'inrdeals', 'earnkaro'],
        pageSlug: 'global-picks'
    },
    '-1003029983162': {
        pageName: 'Deals Hub',
        affiliateTag: 'id=sha678089037',
        platform: 'inrdeals',
        pageSlug: 'deals-hub'
    },
    '-1002991047787': {
        pageName: 'Loot Box',
        affiliateTag: '{{URL}}{{SEP}}ref=sicvppak',
        platform: 'deodap',
        pageSlug: 'loot-box'
    }
};
// Enhanced URL detection regex patterns
const URL_PATTERNS = {
    amazon: /(?:https?:\/\/)?(?:www\.)?amazon\.(?:in|com)\/[^\s]+/gi,
    flipkart: /(?:https?:\/\/)?(?:www\.)?flipkart\.com\/[^\s]+/gi,
    myntra: /(?:https?:\/\/)?(?:www\.)?myntra\.com\/[^\s]+/gi,
    // Comprehensive URL pattern that catches all types
    general: /(?:https?:\/\/)?(?:www\.)?[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*\/[^\s]*/gi,
    // Shortened URL patterns
    shortened: /(?:https?:\/\/)?(?:bit\.ly|tinyurl\.com|goo\.gl|t\.co|short\.link|amzn\.to|fkrt\.it|myntra\.com\/m|flipkart\.com\/dl|a\.co)\/[^\s]+/gi,
    // Affiliate URL patterns (to detect existing affiliate links)
    affiliate: /(?:tag=|ref=|affiliate|partner|cid=|source=linkkit|linksredirect\.com|inrdeals\.com|earnkaro\.com)/gi
};
// Enhanced URL conversion functions with affiliate detection and replacement
function isAffiliateUrl(url) {
    return URL_PATTERNS.affiliate.test(url);
}
function cleanAffiliateUrl(url) {
    try {
        const urlObj = new URL(url);
        // Remove common affiliate parameters
        const affiliateParams = ['tag', 'ref', 'affiliate', 'partner', 'cid', 'source', 'utm_source', 'utm_medium', 'utm_campaign'];
        affiliateParams.forEach(param => urlObj.searchParams.delete(param));
        // Handle specific affiliate URL patterns
        if (url.includes('linksredirect.com') || url.includes('inrdeals.com') || url.includes('earnkaro.com')) {
            // Extract the original URL from affiliate wrapper
            const originalUrl = urlObj.searchParams.get('url');
            if (originalUrl) {
                return decodeURIComponent(originalUrl);
            }
        }
        return urlObj.toString();
    }
    catch {
        // If URL parsing fails, try basic cleaning
        return url.split('?')[0];
    }
}
function convertToAmazonAffiliate(url, tag) {
    try {
        const cleanUrl = cleanAffiliateUrl(url);
        const urlObj = new URL(cleanUrl);
        // Add the affiliate tag
        urlObj.searchParams.set('tag', 'pickntrust03-21');
        urlObj.searchParams.set('linkCode', 'as2');
        urlObj.searchParams.set('camp', '1789');
        urlObj.searchParams.set('creative', '9325');
        return urlObj.toString();
    }
    catch (error) {
        // Fallback for malformed URLs
        const baseUrl = url.split('?')[0];
        return `${baseUrl}?tag=pickntrust03-21&linkCode=as2&camp=1789&creative=9325`;
    }
}
function convertToCuelinks(url) {
    const cleanUrl = cleanAffiliateUrl(url);
    const encodedUrl = encodeURIComponent(cleanUrl);
    return `https://linksredirect.com/?cid=243942&source=linkkit&url=${encodedUrl}`;
}
function convertToInrdeals(url, tag) {
    const cleanUrl = cleanAffiliateUrl(url);
    const baseUrl = 'https://inrdeals.com/redirect';
    if (tag) {
        return `${baseUrl}?url=${encodeURIComponent(cleanUrl)}&${tag}`;
    }
    return `${baseUrl}?url=${encodeURIComponent(cleanUrl)}`;
}
function convertToDeodap(url, tag) {
    const cleanUrl = cleanAffiliateUrl(url);
    return `${cleanUrl}${cleanUrl.includes('?') ? '&' : '?'}${tag.replace('{{URL}}{{SEP}}', '')}`;
}
function convertToEarnkaro(url) {
    const cleanUrl = cleanAffiliateUrl(url);
    const encodedUrl = encodeURIComponent(cleanUrl);
    return `https://earnkaro.com/api/redirect?url=${encodedUrl}`;
}
// Extract product information from message using URL processing service
async function extractProductInfo(message) {
    // Enhanced URL extraction - check for all types of URLs
    let urls = [];
    // First, extract all general URLs
    const generalUrls = message.match(URL_PATTERNS.general) || [];
    // Then, specifically look for shortened URLs
    const shortenedUrls = message.match(URL_PATTERNS.shortened) || [];
    // Combine and deduplicate URLs
    urls = [...new Set([...generalUrls, ...shortenedUrls])];
    // Clean URLs (remove extra characters that might be captured)
    urls = urls.map(url => {
        // Ensure URL has protocol
        if (!url.startsWith('http')) {
            url = 'https://' + url;
        }
        // Remove trailing punctuation
        return url.replace(/[.,;!?]+$/, '');
    });
    if (urls.length === 0) {
        return { urls: [] };
    }
    try {
        // Use URL processing service for the first URL found
        const firstUrl = urls[0];
        console.log(`🔍 Processing URL with URL processing service: ${firstUrl}`);
        const processingResult = await urlProcessingService.processURL(firstUrl);
        if (processingResult.success && processingResult.productCard) {
            const productCard = processingResult.productCard;
            return {
                title: productCard.name,
                price: productCard.price,
                originalPrice: productCard.originalPrice,
                description: productCard.description,
                urls: urls,
                productData: productCard
            };
        }
        else {
            console.log(`⚠️ URL processing failed, falling back to basic extraction: ${processingResult.error}`);
            // Fallback to basic extraction
            return extractBasicProductInfo(message, urls);
        }
    }
    catch (error) {
        console.error(`❌ Error in URL processing service:`, error);
        // Fallback to basic extraction
        return extractBasicProductInfo(message, urls);
    }
}
// Fallback basic extraction method
function extractBasicProductInfo(message, urls) {
    // Handle URL-only posts by attempting to extract product info from URL
    if (message.trim().startsWith('http') && message.trim().split('\n').length === 1) {
        const url = message.trim();
        let title = 'Product from Telegram';
        // Try to extract product info from URL patterns
        if (url.includes('amazon.in') || url.includes('amzn.to')) {
            // Extract from Amazon URL patterns
            const dpMatch = url.match(/\/dp\/([A-Z0-9]+)/);
            const keywordMatch = url.match(/keywords=([^&]+)/);
            if (keywordMatch) {
                title = decodeURIComponent(keywordMatch[1]).replace(/[+_-]/g, ' ').trim();
            }
            else if (dpMatch) {
                title = `Amazon Product ${dpMatch[1]}`;
            }
            else {
                title = 'Amazon Product';
            }
        }
        else if (url.includes('flipkart.com') || url.includes('fkrt.cc')) {
            title = 'Flipkart Product';
        }
        else if (url.includes('myntra.com')) {
            title = 'Myntra Product';
        }
        else if (url.includes('nykaa.com')) {
            title = 'Nykaa Product';
        }
        return {
            title,
            urls: urls,
            description: `Product available at: ${url}`
        };
    }
    // Enhanced title extraction logic for posts with content
    const lines = message.split('\n').filter(line => line.trim());
    let title;
    // Step 1: Look for product-specific patterns first
    // Pattern 1: Lines that contain product keywords and are descriptive
    const productKeywords = ['headphones', 'mouse', 'watch', 'laptop', 'phone', 'smartphone', 'tablet', 'camera', 'speaker', 'earbuds', 'charger', 'cable', 'adapter', 'keyboard', 'monitor', 'tv', 'television', 'gaming', 'wireless', 'bluetooth', 'smart', 'premium', 'pro', 'max', 'mini', 'ultra', 'edition', 'series', 'model'];
    for (const line of lines) {
        const cleanLine = line.replace(/[✨🎯🔥⚡️🎉💥🚀💰❌✅]/g, '').trim();
        // Skip lines that are clearly not product names
        if (cleanLine.startsWith('http') ||
            cleanLine.includes('Deal @') ||
            cleanLine.includes('Reg @') ||
            cleanLine.includes('Price:') ||
            cleanLine.includes('MRP') ||
            cleanLine.includes('₹') ||
            cleanLine.includes('%') ||
            cleanLine.toLowerCase().includes('off') ||
            cleanLine.toLowerCase().includes('discount') ||
            cleanLine.toLowerCase().includes('save') ||
            cleanLine.toLowerCase().includes('limited') ||
            cleanLine.toLowerCase().includes('flash sale') ||
            cleanLine.length < 8) {
            continue;
        }
        // Check if line contains product keywords or looks like a product name
        const lowerLine = cleanLine.toLowerCase();
        const hasProductKeyword = productKeywords.some(keyword => lowerLine.includes(keyword));
        const looksLikeProductName = cleanLine.length > 15 && cleanLine.length < 100 &&
            /[a-zA-Z]/.test(cleanLine) &&
            !cleanLine.match(/^[🔥🎉💥⚡️✨🎯🚀💰❌✅\s]+$/);
        if (hasProductKeyword || looksLikeProductName) {
            title = cleanLine;
            break;
        }
    }
    // Step 2: If no product-specific title found, use improved fallback logic
    if (!title) {
        // Look for the longest meaningful line that's not promotional text
        const meaningfulLines = lines
            .map(line => line.replace(/[✨🎯🔥⚡️🎉💥🚀💰❌✅]/g, '').trim())
            .filter(line => !line.startsWith('http') &&
            line.length > 8 &&
            line.length < 100 &&
            !line.includes('Deal @') &&
            !line.includes('Reg @') &&
            !line.includes('Price:') &&
            !line.includes('MRP') &&
            !line.includes('₹') &&
            !line.includes('%') &&
            !line.toLowerCase().includes('off') &&
            !line.toLowerCase().includes('discount') &&
            !line.toLowerCase().includes('save') &&
            !line.toLowerCase().includes('limited') &&
            !line.toLowerCase().includes('flash sale') &&
            /[a-zA-Z]/.test(line));
        if (meaningfulLines.length > 0) {
            // Prefer longer, more descriptive lines
            title = meaningfulLines.reduce((longest, current) => current.length > longest.length ? current : longest);
        }
    }
    // Step 3: Final fallback - use first line if nothing else works
    if (!title && lines.length > 0) {
        title = lines[0].replace(/[✨🎯🔥⚡️🎉💥🚀💰❌✅]/g, '').trim();
        // If first line is still not good, try second line
        if (title.length < 8 || title.startsWith('http') || title.includes('₹')) {
            title = lines[1]?.replace(/[✨🎯🔥⚡️🎉💥🚀💰❌✅]/g, '').trim() || 'Product from Telegram';
        }
    }
    // Ensure we have a title
    if (!title || title.length < 3) {
        title = 'Product from Telegram';
    }
    // Enhanced price extraction - look for multiple patterns
    let price;
    let originalPrice;
    let discount;
    // Pattern 1: Multiple ₹ symbols in sequence (₹X ₹Y format)
    const multipleRupeeMatches = message.match(/₹([\d,]+(?:\.\d+)?)\s*₹([\d,]+(?:\.\d+)?)/g);
    if (multipleRupeeMatches) {
        const matches = multipleRupeeMatches[0].match(/₹([\d,]+(?:\.\d+)?)\s*₹([\d,]+(?:\.\d+)?)/);
        if (matches) {
            price = `₹${matches[1]}`;
            originalPrice = `₹${matches[2]}`;
        }
    }
    // Pattern 2: Single ₹ symbols (take first two if available)
    if (!price) {
        const rupeeMatches = message.match(/₹([\d,]+(?:\.\d+)?)(k?)/gi);
        if (rupeeMatches && rupeeMatches.length >= 2) {
            // Extract price and handle 'k' suffix
            const firstMatch = rupeeMatches[0].match(/₹([\d,]+(?:\.\d+)?)(k?)/i);
            const secondMatch = rupeeMatches[1].match(/₹([\d,]+(?:\.\d+)?)(k?)/i);
            if (firstMatch) {
                let priceValue = firstMatch[1].replace(/,/g, '');
                if (firstMatch[2] && firstMatch[2].toLowerCase() === 'k') {
                    priceValue = (parseFloat(priceValue) * 1000).toString();
                }
                price = `₹${priceValue}`;
            }
            if (secondMatch) {
                let originalPriceValue = secondMatch[1].replace(/,/g, '');
                if (secondMatch[2] && secondMatch[2].toLowerCase() === 'k') {
                    originalPriceValue = (parseFloat(originalPriceValue) * 1000).toString();
                }
                originalPrice = `₹${originalPriceValue}`;
            }
        }
        else if (rupeeMatches && rupeeMatches.length === 1) {
            const singleMatch = rupeeMatches[0].match(/₹([\d,]+(?:\.\d+)?)(k?)/i);
            if (singleMatch) {
                let priceValue = singleMatch[1].replace(/,/g, '');
                if (singleMatch[2] && singleMatch[2].toLowerCase() === 'k') {
                    priceValue = (parseFloat(priceValue) * 1000).toString();
                }
                price = `₹${priceValue}`;
            }
        }
    }
    // Pattern 3: Deal @ price format with 'k' suffix handling
    const dealMatch = message.match(/Deal\s*@\s*₹?([\d,]+(?:\.\d+)?)(k?)/i);
    if (dealMatch && !price) {
        let dealPrice = dealMatch[1].replace(/,/g, '');
        if (dealMatch[2] && dealMatch[2].toLowerCase() === 'k') {
            dealPrice = (parseFloat(dealPrice) * 1000).toString();
        }
        price = `₹${dealPrice}`;
    }
    // Pattern 4: Reg @ price format (for original price) with improved 'k' handling
    const regMatch = message.match(/Reg\s*@\s*₹?([\d,]+(?:\.\d+)?)(k?)/i);
    if (regMatch) {
        let regPrice = regMatch[1].replace(/,/g, '');
        // Handle 'k' suffix (thousands)
        if (regMatch[2] && regMatch[2].toLowerCase() === 'k') {
            regPrice = (parseFloat(regPrice) * 1000).toString();
        }
        if (!originalPrice) {
            originalPrice = `₹${regPrice}`;
        }
        else if (!price) {
            price = `₹${regPrice}`;
        }
    }
    // Pattern 5: Price: format with 'k' suffix handling
    const priceColonMatch = message.match(/Price:\s*₹?([\d,]+(?:\.\d+)?)(k?)/i);
    if (priceColonMatch && !price) {
        let priceValue = priceColonMatch[1].replace(/,/g, '');
        if (priceColonMatch[2] && priceColonMatch[2].toLowerCase() === 'k') {
            priceValue = (parseFloat(priceValue) * 1000).toString();
        }
        price = `₹${priceValue}`;
    }
    // Pattern 6: MRP format with 'k' suffix handling
    const mrpMatch = message.match(/MRP\s*:?\s*₹?([\d,]+(?:\.\d+)?)(k?)/i);
    if (mrpMatch && !originalPrice) {
        let mrpPrice = mrpMatch[1].replace(/,/g, '');
        if (mrpMatch[2] && mrpMatch[2].toLowerCase() === 'k') {
            mrpPrice = (parseFloat(mrpPrice) * 1000).toString();
        }
        originalPrice = `₹${mrpPrice}`;
    }
    // Pattern 7: Discount percentage - enhanced patterns
    const discountPercentMatch = message.match(/(\d+)%\s*(?:off|discount|save|savings)/i);
    if (discountPercentMatch) {
        discount = `${discountPercentMatch[1]}%`;
    }
    // Pattern 8: Additional discount patterns
    if (!discount) {
        const saveMatch = message.match(/save\s*₹?([\d,]+)/i);
        if (saveMatch && price && originalPrice) {
            const savedAmount = parseFloat(saveMatch[1].replace(/,/g, ''));
            const originalPriceNum = parseFloat(originalPrice.replace(/₹|,/g, ''));
            if (originalPriceNum > 0) {
                const discountPercent = Math.round((savedAmount / originalPriceNum) * 100);
                discount = `${discountPercent}%`;
            }
        }
    }
    // Calculate discount if we have both prices but no explicit discount
    if (price && originalPrice && !discount) {
        try {
            const priceNum = parseFloat(price.replace(/₹|,/g, ''));
            const originalPriceNum = parseFloat(originalPrice.replace(/₹|,/g, ''));
            if (originalPriceNum > priceNum && originalPriceNum > 0) {
                const discountPercent = Math.round(((originalPriceNum - priceNum) / originalPriceNum) * 100);
                if (discountPercent > 0 && discountPercent <= 100) {
                    discount = `${discountPercent}%`;
                }
            }
        }
        catch (error) {
            console.log('Error calculating discount:', error);
        }
    }
    // Log extracted price information for debugging
    console.log(`💰 Price extraction results:`, {
        price,
        originalPrice,
        discount,
        messagePreview: message.substring(0, 100)
    });
    // Extract description (lines that don't contain URLs, excluding price lines)
    const description = lines
        .filter(line => !URL_PATTERNS.general.test(line) &&
        !line.includes('Deal @') &&
        !line.includes('Reg @') &&
        !line.includes('Price:') &&
        !line.includes('MRP') &&
        !line.match(/\d+%\s*(?:off|discount)/i) &&
        line !== title)
        .slice(0, 3) // Take up to 3 lines
        .join(' ')
        .substring(0, 200)
        .trim();
    return {
        title,
        price,
        originalPrice,
        discount,
        description: description || message.substring(0, 200).replace(/https?:\/\/[^\s]+/g, '').trim(),
        urls
    };
}
// Enhanced URL conversion based on platform with affiliate detection
function convertUrls(urls, config) {
    const convertedUrls = [];
    for (const url of urls) {
        console.log(`🔄 Converting URL: ${url}`);
        // Loot Box requirement: do NOT convert links, keep exactly as posted
        // Only bypass conversion for loot-box page
        if (config?.pageSlug === 'loot-box') {
            console.log('🎁 Loot Box page detected — bypassing affiliate conversion, preserving original URL');
            convertedUrls.push(url);
            continue;
        }
        // Check if URL is already an affiliate URL
        if (isAffiliateUrl(url)) {
            console.log(`🔍 Detected affiliate URL, cleaning and converting to user's affiliate`);
        }
        switch (config.platform) {
            case 'amazon':
                convertedUrls.push(convertToAmazonAffiliate(url, config.affiliateTag));
                break;
            case 'cuelinks':
                convertedUrls.push(convertToCuelinks(url));
                break;
            case 'inrdeals':
                convertedUrls.push(convertToInrdeals(url, config.affiliateTag));
                break;
            case 'earnkaro':
                convertedUrls.push(convertToEarnkaro(url));
                break;
            case 'deodap':
                convertedUrls.push(convertToDeodap(url, config.affiliateTag));
                break;
            case 'multiple':
                // For multiple platforms, try to detect the best platform for each URL
                if (config.platforms && Array.isArray(config.platforms) && config.platforms.length > 0) {
                    // Use the first platform in the list as primary
                    const primaryPlatform = config.platforms[0];
                    console.log(`🔄 Using primary platform: ${primaryPlatform} for multiple platform config`);
                    switch (primaryPlatform) {
                        case 'cuelinks':
                            convertedUrls.push(convertToCuelinks(url));
                            break;
                        case 'inrdeals':
                            convertedUrls.push(convertToInrdeals(url));
                            break;
                        case 'earnkaro':
                            convertedUrls.push(convertToEarnkaro(url));
                            break;
                        default:
                            console.log(`⚠️ Unknown primary platform ${primaryPlatform}, falling back to cuelinks`);
                            convertedUrls.push(convertToCuelinks(url)); // Default fallback
                    }
                }
                else {
                    console.log(`⚠️ No platforms array found in config, defaulting to cuelinks`);
                    convertedUrls.push(convertToCuelinks(url)); // Default to cuelinks
                }
                break;
            default:
                // Even for unknown platforms, try to convert through cuelinks
                convertedUrls.push(convertToCuelinks(url));
        }
        console.log(`✅ Converted to: ${convertedUrls[convertedUrls.length - 1]}`);
    }
    return convertedUrls;
}
// Extract image from message
async function extractImageUrl(msg) {
    if (msg.photo && msg.photo.length > 0) {
        // Get the highest resolution photo
        const photo = msg.photo[msg.photo.length - 1];
        try {
            const fileLink = await bot.getFileLink(photo.file_id);
            return fileLink;
        }
        catch (error) {
            console.error('Error getting photo link:', error);
        }
    }
    return null;
}
// Save message to channel_posts table first
async function saveToChannelPosts(msg, channelConfig, messageText, extractedUrls, imageUrl = null) {
    try {
        // Use the same database path convention as other server modules
        const dbPath = getDatabasePath();
        const sqliteDb = new Database(dbPath);
        // Updated SQL to match actual table schema
        const insertSQL = `
      INSERT INTO channel_posts (
        channel_id, channel_name, website_page, message_id, original_text, 
        processed_text, extracted_urls, is_processed, is_posted, 
        telegram_timestamp, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;
        const now = Math.floor(Date.now() / 1000);
        const values = [
            msg.chat.id.toString(),
            channelConfig.pageName,
            channelConfig.pageSlug || 'prime-picks',
            msg.message_id,
            messageText,
            messageText, // processed_text same as original for now
            JSON.stringify(extractedUrls),
            0, // is_processed - will be updated after successful processing
            0, // is_posted
            msg.date || now, // telegram_timestamp
            now
        ];
        const result = sqliteDb.prepare(insertSQL).run(...values);
        sqliteDb.close();
        console.log(`📝 Message saved to channel_posts with ID: ${result.lastInsertRowid}`);
        return result.lastInsertRowid;
    }
    catch (error) {
        console.error(`❌ Error saving to channel_posts:`, error);
        return null;
    }
}
// Update channel_posts record after processing
async function updateChannelPostStatus(channelPostId, isProcessed, isPosted, error) {
    try {
        // Use the project root database file like other services
        const dbPath = getDatabasePath();
        const sqliteDb = new Database(dbPath);
        const updateSQL = `
      UPDATE channel_posts 
      SET is_processed = ?, is_posted = ?, processed_at = ?, processing_error = ?
      WHERE id = ?
    `;
        const now = Math.floor(Date.now() / 1000);
        const values = [
            isProcessed ? 1 : 0,
            isPosted ? 1 : 0,
            isProcessed ? now : null,
            error || null,
            channelPostId
        ];
        sqliteDb.prepare(updateSQL).run(...values);
        sqliteDb.close();
        console.log(`📊 Updated channel_posts ID ${channelPostId}: processed=${isProcessed}, posted=${isPosted}`);
    }
    catch (error) {
        console.error(`❌ Error updating channel_posts status:`, error);
    }
}
// Save product to database
async function saveProductToDatabase(productData, channelConfig, channelPostId, productInfo) {
    try {
        // Extract numeric price values
        const priceMatch = productData.price?.match(/[\d,]+/);
        const originalPriceMatch = productData.originalPrice?.match(/[\d,]+/);
        const numericPrice = priceMatch ? parseFloat(priceMatch[0].replace(/,/g, '')) : 0;
        const numericOriginalPrice = originalPriceMatch ? parseFloat(originalPriceMatch[0].replace(/,/g, '')) : null;
        // Calculate discount if both prices are available
        const discount = (numericOriginalPrice && numericPrice && numericOriginalPrice > numericPrice)
            ? Math.round(((numericOriginalPrice - numericPrice) / numericOriginalPrice) * 100)
            : null;
        // Apply smart categorization for bot/RSS automation
        const categorization = categorizeForAutomation(productData.title || 'Product from Telegram', productData.description || '', channelConfig.pageSlug, channelConfig.platform);
        console.log(`🤖 Smart categorization result:`, {
            title: productData.title,
            channel: channelConfig.pageSlug,
            isFeatured: categorization.isFeatured,
            isService: categorization.isService,
            isAIApp: categorization.isAIApp,
            category: categorization.category,
            confidence: categorization.confidence
        });
        // Determine affiliate URL with conversion based on channel/platform
        const sourceUrls = (productData.urls && productData.urls.length > 0) ? productData.urls : (productInfo?.urls || []);
        const convertedAffiliateUrls = convertUrls(sourceUrls, channelConfig);
        const affiliateUrlToSave = convertedAffiliateUrls[0] || (sourceUrls[0] || '');
        // Use raw SQL insert matching the actual unified_content table schema
        const insertSQL = `
      INSERT INTO unified_content (
        title, description, price, original_price, image_url, affiliate_url,
        content_type, page_type, category, subcategory, source_type, source_id,
        affiliate_platform, rating, review_count, discount, currency, gender,
        is_active, is_featured, display_order, display_pages,
        has_timer, timer_duration, timer_start_time,
        created_at, updated_at, status, visibility, processing_status
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;
        const values = [
            productData.title || 'Product from Telegram',
            productData.description || '',
            numericPrice.toString(),
            numericOriginalPrice?.toString() || null,
            productData.imageUrl || 'https://via.placeholder.com/300x300?text=Product',
            affiliateUrlToSave,
            'product',
            channelConfig.pageSlug,
            categorization.category, // Use smart categorization result
            null, // subcategory
            'telegram', // source_type
            channelPostId?.toString() || channelConfig.pageSlug, // Use channel_posts ID as source_id
            channelConfig.platform, // affiliate_platform reflects channel/platform (e.g., deodap)
            '4.0',
            100,
            discount,
            'INR',
            null, // gender
            1, // is_active
            categorization.isFeatured ? 1 : 0, // Smart featured detection
            0, // display_order
            JSON.stringify(Array.from(new Set([channelConfig.pageSlug, ...categorization.displayPages]))), // Ensure channel page appears
            0, // has_timer
            null, // timer_duration
            null, // timer_start_time
            Math.floor(Date.now() / 1000), // created_at
            Math.floor(Date.now() / 1000), // updated_at
            'active', // status
            'public', // visibility
            'completed', // processing_status
        ];
        // Execute raw SQL using the database connection
        // Align DB path with storage/db modules (server/../database.sqlite)
        const dbPath = getDatabasePath();
        const sqliteDb = new Database(dbPath);
        const result = sqliteDb.prepare(insertSQL).run(...values);
        sqliteDb.close();
        console.log(`✅ Product saved to unified_content for ${channelConfig.pageName}:`, productData.title || 'Product from Telegram');
        console.log(`📊 Product ID: ${result.lastInsertRowid}, Page: ${channelConfig.pageSlug}, Channel Post ID: ${channelPostId}`);
        console.log(`🎯 Auto-categorized as: Featured=${categorization.isFeatured}, Service=${categorization.isService}, AI/App=${categorization.isAIApp}`);
        console.log(`📄 Will appear on pages: ${categorization.displayPages.join(', ')}`);
        return result.lastInsertRowid;
    }
    catch (error) {
        console.error(`❌ Error saving product to database:`, error);
        console.error('Error details:', error.message);
        throw error;
    }
}
// Message processing function
async function processMessage(msg) {
    console.log('🔄 processMessage called with:', {
        messageId: msg.message_id,
        chatId: msg.chat?.id,
        chatTitle: msg.chat?.title,
        hasText: !!msg.text,
        hasCaption: !!msg.caption,
        hasPhoto: !!msg.photo
    });
    const chatId = msg.chat.id.toString();
    // Route Travel Picks channel posts to dedicated travel bot
    try {
        const travelStatus = travelPicksBot.getStatus();
        if (chatId === travelStatus.channelId) {
            console.log(`🧳 Routing message ${msg.message_id} from Travel Picks (${chatId}) to travel bot`);
            await travelPicksBot.processMessage(msg);
            return;
        }
    }
    catch (routeErr) {
        console.warn('⚠️ Travel routing check failed:', routeErr?.message || routeErr);
    }
    // Master bot handles non-travel channels below
    let channelConfig = CHANNEL_CONFIGS[chatId];
    // Safe fallback: derive a default config so unknown channels still post to site
    if (!channelConfig) {
        const title = (msg.chat?.title || '').trim();
        const slugify = (s) => s
            .toLowerCase()
            .replace(/[^a-z0-9]+/g, '-')
            .replace(/^-+|-+$/g, '')
            .slice(0, 40) || 'value-picks';
        const derivedSlug = title ? slugify(title) : 'value-picks';
        channelConfig = {
            pageName: title || 'Value Picks',
            affiliateTag: '',
            platform: 'multiple',
            platforms: ['cuelinks', 'inrdeals', 'earnkaro'],
            pageSlug: derivedSlug
        };
        console.log(`ℹ️ Using fallback channel config for ${chatId}:`, channelConfig);
    }
    console.log(`✅ Processing message from ${channelConfig.pageName} (${chatId})`);
    // Enhanced message text extraction for photo messages
    let messageText = '';
    // For photo messages, combine caption and any text
    if (msg.photo && msg.photo.length > 0) {
        console.log('📸 Processing photo message');
        messageText = msg.caption || '';
        // If there's also text in the message, combine them
        if (msg.text) {
            messageText = messageText ? `${messageText}\n${msg.text}` : msg.text;
        }
    }
    else {
        // For regular text messages
        messageText = msg.text || msg.caption || '';
    }
    console.log(`📝 Message text for processing: ${messageText.substring(0, 200)}...`);
    // Capture URLs present only in Telegram entities (e.g., text_link), and merge into text
    function extractEntityUrls(m) {
        const out = [];
        const collect = (entities, text) => {
            if (!entities || !Array.isArray(entities))
                return;
            for (const e of entities) {
                try {
                    if (e.type === 'text_link' && e.url) {
                        out.push(String(e.url));
                    }
                    else if (e.type === 'url' && typeof e.offset === 'number' && typeof e.length === 'number' && typeof text === 'string') {
                        const urlText = text.substring(e.offset, e.offset + e.length);
                        if (urlText)
                            out.push(urlText);
                    }
                }
                catch { }
            }
        };
        collect(m.entities, m.text || '');
        collect(m.caption_entities, m.caption || '');
        return out;
    }
    const entityUrls = extractEntityUrls(msg);
    if (entityUrls.length > 0) {
        messageText = `${messageText}\n${entityUrls.join('\n')}`.trim();
        console.log('🔗 Added entity URLs to message text:', entityUrls);
    }
    // Extract product information using URL processing service
    const productInfo = await extractProductInfo(messageText);
    if (productInfo.urls.length === 0) {
        console.log('⚠️ No URLs found via text parsing');
        if (entityUrls.length === 0) {
            console.log('❌ No URLs found in entities either, skipping...');
            return;
        }
        // Fallback: use entity URLs directly
        productInfo.urls = entityUrls;
        console.log(`🔗 Using ${entityUrls.length} URLs from entities`);
    }
    console.log(`🔗 Found ${productInfo.urls.length} URLs, proceeding to save...`);
    // Save message to channel_posts table first
    const channelPostId = await saveToChannelPosts(msg, channelConfig, messageText, productInfo.urls);
    if (!channelPostId) {
        console.error('❌ Failed to save message to channel_posts, aborting...');
        await notifyAdmin(`❌ <b>Channel Post Save Failed</b>\n` +
            `• Channel: <code>${channelConfig.pageName}</code> (${chatId})\n` +
            `• Message ID: <code>${msg.message_id}</code>`);
        return;
    }
    console.log(`✅ Message saved to channel_posts with ID: ${channelPostId}`);
    try {
        // Extract image
        const imageUrl = await extractImageUrl(msg);
        // Update the channel_posts record with the image URL if found
        if (imageUrl && channelPostId) {
            // Use the same project-root database path convention as elsewhere
            const dbPath = getDatabasePath();
            const sqliteDb = new Database(dbPath);
            const updateSQL = `UPDATE channel_posts SET image_url = ? WHERE id = ?`;
            sqliteDb.prepare(updateSQL).run(imageUrl, channelPostId);
            sqliteDb.close();
            console.log(`📸 Image URL saved: ${imageUrl}`);
        }
        let productData;
        // If URL processing service provided complete product data, use it
        if (productInfo.productData) {
            // For photo messages, enhance title with message text if URL processing didn't get a good title
            let enhancedTitle = productInfo.productData.name;
            if (msg.photo && msg.photo.length > 0 && messageText) {
                // Extract a better title from the message text for photo posts
                const lines = messageText.split('\n').filter(line => line.trim());
                const firstLine = lines[0]?.replace(/[✨🎯🔥⚡️🎉💥🚀💰❌✅]/g, '').trim();
                // Use message text title if it's more descriptive than URL-extracted title
                if (firstLine && firstLine.length > 10 && !firstLine.startsWith('http') &&
                    (!enhancedTitle || enhancedTitle.length < 20 || enhancedTitle === 'Product from Telegram')) {
                    enhancedTitle = firstLine;
                }
            }
            // Prioritize product image from URL processing service over Telegram photo
            let finalImageUrl = productInfo.productData.imageUrl;
            // Only use Telegram image if no product image was found from URL processing
            if (!finalImageUrl || finalImageUrl.includes('placeholder') || finalImageUrl.includes('via.placeholder')) {
                finalImageUrl = imageUrl || '/api/placeholder/300/300';
            }
            console.log(`📸 Image URL decision: Product=${productInfo.productData.imageUrl}, Telegram=${imageUrl}, Final=${finalImageUrl}`);
            productData = {
                ...productInfo.productData,
                title: enhancedTitle,
                imageUrl: finalImageUrl,
                messageId: msg.message_id,
                hasPhoto: !!(msg.photo && msg.photo.length > 0)
            };
        }
        else {
            // Fallback: Convert URLs to affiliate links and use basic product info
            const affiliateUrls = convertUrls(productInfo.urls || [], channelConfig);
            // For photo messages, enhance the extracted info
            let enhancedProductInfo = { ...productInfo };
            if (msg.photo && msg.photo.length > 0) {
                console.log('📸 Enhancing product info for photo message');
                // Add URL to title if available and title is generic
                if (productInfo.urls && productInfo.urls.length > 0 &&
                    (!productInfo.title || productInfo.title === 'Product from Telegram' || productInfo.title.length < 15)) {
                    try {
                        const urlDomain = new URL(productInfo.urls[0]).hostname.replace('www.', '');
                        enhancedProductInfo.title = `${productInfo.title || 'Product'} - ${urlDomain}`;
                    }
                    catch (error) {
                        console.error('Error parsing URL for domain:', error);
                        enhancedProductInfo.title = productInfo.title || 'Product from Telegram';
                    }
                }
            }
            productData = {
                title: enhancedProductInfo.title || 'Product from Telegram',
                price: enhancedProductInfo.price || null,
                originalPrice: enhancedProductInfo.originalPrice || null,
                discount: enhancedProductInfo.discount || null,
                description: enhancedProductInfo.description || '',
                urls: affiliateUrls,
                imageUrl: imageUrl || '/api/placeholder/300/300',
                messageId: msg.message_id,
                hasPhoto: !!(msg.photo && msg.photo.length > 0),
                // Ensure price data is preserved from basic extraction
                currency: 'INR',
                name: enhancedProductInfo.title || 'Product from Telegram'
            };
        }
        // Log enhanced product data for debugging
        console.log('📦 Enhanced product data:', {
            title: productData.title,
            price: productData.price,
            originalPrice: productData.originalPrice,
            discount: productData.discount,
            hasPhoto: productData.hasPhoto,
            urlCount: productData.urls?.length || 0
        });
        // Save to unified_content database
        const productId = await saveProductToDatabase(productData, channelConfig, Number(channelPostId), productInfo);
        // Update channel_posts status to processed
        await updateChannelPostStatus(Number(channelPostId), true, false);
        console.log(`✅ Product processed and saved for ${channelConfig.pageName} - Channel Post ID: ${channelPostId}, Product ID: ${productId}`);
    }
    catch (error) {
        console.error(`❌ Error processing message:`, error);
        // Update channel_posts status to show processing error
        await updateChannelPostStatus(Number(channelPostId), false, false, error.message);
        // Notify admin about processing/upload failure
        await notifyAdmin(`❌ <b>Processing Failed</b>\n` +
            `• Channel: <code>${channelConfig.pageName}</code> (${chatId})\n` +
            `• Message ID: <code>${msg.message_id}</code>\n` +
            `• Error: <code>${error.message || 'unknown error'}</code>`);
    }
}
// Export the bot, functions, and TelegramBotManager
export { bot, sendTelegramNotification, TelegramBotManager };
