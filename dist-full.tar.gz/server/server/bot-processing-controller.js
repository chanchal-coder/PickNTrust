// Simple in-memory controller to enable/disable Telegram bot processing at runtime
// Defaults to enabled; can be toggled via admin API without restarting the server
const state = {
    enabled: true,
    lastChangedAt: undefined,
};
export const botProcessingController = {
    isEnabled() {
        return state.enabled === true;
    },
    setEnabled(enabled) {
        state.enabled = !!enabled;
        state.lastChangedAt = new Date().toISOString();
        return { ...state };
    },
    getState() {
        return { ...state };
    },
};
export default botProcessingController;
