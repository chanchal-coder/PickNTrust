// @ts-nocheck
import { products, blogPosts, newsletterSubscribers, categories, affiliateNetworks, adminUsers, announcements } from "../shared/sqlite-schema.js";
import { dbInstance as db } from "./db.js";
import { eq, desc, ne, sql } from "drizzle-orm";
export class MemStorage {
    // Implement all required methods as empty stubs for now
    async getProducts() {
        return [];
    }
    async getFeaturedProducts() {
        return [];
    }
    async getProductsByCategory(category) {
        return [];
    }
    async getProduct(id) {
        return undefined;
    }
    async getCategories() {
        return [];
    }
    async getBlogPosts() {
        return [];
    }
    async subscribeToNewsletter(subscriber) {
        throw new Error("Method not implemented.");
    }
    async getAffiliateNetworks() {
        return [];
    }
    async getActiveAffiliateNetworks() {
        return [];
    }
    async addAffiliateNetwork(network) {
        throw new Error("Method not implemented.");
    }
    async updateAffiliateNetwork(id, network) {
        throw new Error("Method not implemented.");
    }
    async addProduct(product) {
        throw new Error("Method not implemented.");
    }
    async deleteProduct(id) {
        return false;
    }
    async updateProduct(id, updates) {
        return null;
    }
    async cleanupExpiredProducts() {
        return 0;
    }
    async addBlogPost(blogPost) {
        throw new Error("Method not implemented.");
    }
    async deleteBlogPost(id) {
        return false;
    }
    async updateBlogPost(id, updates) {
        return null;
    }
    async cleanupExpiredBlogPosts() {
        return 0;
    }
    // Announcements
    async getAnnouncements() {
        return [];
    }
    async createAnnouncement(announcement) {
        throw new Error("Method not implemented.");
    }
    async updateAnnouncement(id, updates) {
        return null;
    }
    async deleteAnnouncement(id) {
        return false;
    }
    // Admin User Management
    async getAdminByEmail(email) {
        return undefined;
    }
    async getAdminByUsername(username) {
        return undefined;
    }
    async getAdminById(id) {
        return undefined;
    }
    async createAdmin(admin) {
        throw new Error("Method not implemented.");
    }
    async updateAdminPassword(id, passwordHash) {
        return false;
    }
    async setResetToken(email, token, expiry) {
        return false;
    }
    async validateResetToken(token) {
        return undefined;
    }
    async clearResetToken(id) {
        return false;
    }
    async updateLastLogin(id) {
        return false;
    }
}
export class DatabaseStorage {
    // Products
    async getProducts() {
        // Clean up expired products first
        await this.cleanupExpiredProducts();
        return await db.select().from(products).orderBy(desc(products.id));
    }
    async getFeaturedProducts() {
        // Clean up expired products first
        await this.cleanupExpiredProducts();
        return await db.select().from(products).where(eq(products.isFeatured, true)).orderBy(desc(products.id));
    }
    async getProductsByCategory(category) {
        return await db.select().from(products).where(eq(products.category, category)).orderBy(desc(products.id));
    }
    async getProduct(id) {
        const [product] = await db.select().from(products).where(eq(products.id, id));
        return product || undefined;
    }
    // Categories
    async getCategories() {
        // Simplified to just select all categories without subquery and ordering
        return await db.select().from(categories);
    }
    // Blog Posts
    async getBlogPosts() {
        return await db.select().from(blogPosts).orderBy(desc(blogPosts.publishedAt));
    }
    // Newsletter
    async subscribeToNewsletter(subscriber) {
        const [newSubscriber] = await db
            .insert(newsletterSubscribers)
            .values(subscriber)
            .returning();
        return newSubscriber;
    }
    // Affiliate Networks
    async getAffiliateNetworks() {
        return await db.select().from(affiliateNetworks).orderBy(affiliateNetworks.name);
    }
    async getActiveAffiliateNetworks() {
        return await db.select().from(affiliateNetworks).where(eq(affiliateNetworks.isActive, true)).orderBy(affiliateNetworks.name);
    }
    async addAffiliateNetwork(network) {
        const [newNetwork] = await db
            .insert(affiliateNetworks)
            .values(network)
            .returning();
        return newNetwork;
    }
    async updateAffiliateNetwork(id, network) {
        const [updatedNetwork] = await db
            .update(affiliateNetworks)
            .set(network)
            .where(eq(affiliateNetworks.id, id))
            .returning();
        return updatedNetwork;
    }
    // Timer cleanup method - removes expired products
    async cleanupExpiredProducts() {
        const now = new Date();
        // For SQLite, we need to use different syntax for date operations
        const result = await db
            .delete(products)
            .where(sql `
        has_timer = true 
        AND timer_start_time IS NOT NULL 
        AND timer_duration IS NOT NULL 
        AND datetime(timer_start_time, '+' || timer_duration || ' hours') < datetime('now')
      `);
        // For SQLite, we need to check the result differently
        return 1; // SQLite doesn't return rowCount, so we'll return 1 for now
    }
    async cleanupExpiredBlogPosts() {
        const now = new Date();
        // For SQLite, we need to use different syntax for date operations
        const result = await db
            .delete(blogPosts)
            .where(sql `
        has_timer = true 
        AND timer_start_time IS NOT NULL 
        AND timer_duration IS NOT NULL 
        AND datetime(timer_start_time, '+' || timer_duration || ' hours') < datetime('now')
      `);
        // For SQLite, we need to check the result differently
        return 1; // SQLite doesn't return rowCount, so we'll return 1 for now
    }
    // Admin Product Management
    async addProduct(product) {
        // Handle timer logic
        const productData = {
            ...product,
            // Set timerStartTime to now if timer is enabled
            timerStartTime: product.hasTimer ? new Date() : null,
            // Ensure timerDuration is null if timer is disabled
            timerDuration: product.hasTimer ? product.timerDuration : null
        };
        const [newProduct] = await db
            .insert(products)
            .values(productData)
            .returning();
        return newProduct;
    }
    async deleteProduct(id) {
        const result = await db.delete(products).where(eq(products.id, id));
        // For SQLite, we'll assume it worked
        return true;
    }
    async updateProduct(id, updates) {
        const [updatedProduct] = await db
            .update(products)
            .set(updates)
            .where(eq(products.id, id))
            .returning();
        return updatedProduct || null;
    }
    // Blog Management
    async addBlogPost(blogPost) {
        const blogPostData = {
            ...blogPost,
            hasTimer: blogPost.hasTimer || false,
            timerDuration: blogPost.hasTimer && blogPost.timerDuration ? parseInt(blogPost.timerDuration.toString()) : null,
            timerStartTime: blogPost.hasTimer ? new Date() : null,
            publishedAt: new Date(blogPost.publishedAt || new Date()),
            slug: blogPost.slug || blogPost.title.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
            excerpt: blogPost.excerpt || '',
            readTime: blogPost.readTime || '5 min read',
            imageUrl: blogPost.imageUrl || '',
            category: blogPost.category || 'General',
            title: blogPost.title || 'Untitled',
            content: blogPost.content || '',
        };
        const [newBlogPost] = await db
            .insert(blogPosts)
            .values(blogPostData)
            .returning();
        return newBlogPost;
    }
    async deleteBlogPost(id) {
        const result = await db.delete(blogPosts).where(eq(blogPosts.id, id));
        // For SQLite, we'll assume it worked
        return true;
    }
    async updateBlogPost(id, updates) {
        const [updatedBlogPost] = await db
            .update(blogPosts)
            .set(updates)
            .where(eq(blogPosts.id, id))
            .returning();
        return updatedBlogPost || null;
    }
    // Announcements
    async getAnnouncements() {
        return await db.select().from(announcements).orderBy(desc(announcements.createdAt));
    }
    async createAnnouncement(announcement) {
        if (announcement.isActive) {
            await db.update(announcements).set({ isActive: false });
        }
        const [newAnnouncement] = await db.insert(announcements).values({
            ...announcement,
            createdAt: new Date()
        }).returning();
        return newAnnouncement;
    }
    async updateAnnouncement(id, updates) {
        if (updates.isActive) {
            await db.update(announcements)
                .set({ isActive: false })
                .where(ne(announcements.id, id));
        }
        const [updatedAnnouncement] = await db.update(announcements)
            .set(updates)
            .where(eq(announcements.id, id))
            .returning();
        return updatedAnnouncement || null;
    }
    async deleteAnnouncement(id) {
        const result = await db.delete(announcements).where(eq(announcements.id, id));
        return true;
    }
    // Admin User Management
    async getAdminByEmail(email) {
        const [admin] = await db.select().from(adminUsers).where(eq(adminUsers.email, email));
        return admin || undefined;
    }
    async getAdminByUsername(username) {
        const [admin] = await db.select().from(adminUsers).where(eq(adminUsers.username, username));
        return admin || undefined;
    }
    async getAdminById(id) {
        const [admin] = await db.select().from(adminUsers).where(eq(adminUsers.id, id));
        return admin || undefined;
    }
    async createAdmin(admin) {
        const [newAdmin] = await db
            .insert(adminUsers)
            .values(admin)
            .returning();
        return newAdmin;
    }
    async updateAdminPassword(id, passwordHash) {
        const result = await db
            .update(adminUsers)
            .set({ passwordHash })
            .where(eq(adminUsers.id, id));
        // For SQLite, we'll assume it worked
        return true;
    }
    async setResetToken(email, token, expiry) {
        const result = await db
            .update(adminUsers)
            .set({ resetToken: token, resetTokenExpiry: expiry })
            .where(eq(adminUsers.email, email));
        // For SQLite, we'll assume it worked
        return true;
    }
    async validateResetToken(token) {
        const [admin] = await db
            .select()
            .from(adminUsers)
            .where(eq(adminUsers.resetToken, token));
        if (!admin || !admin.resetTokenExpiry || admin.resetTokenExpiry < new Date()) {
            return undefined;
        }
        return admin;
    }
    async clearResetToken(id) {
        const result = await db
            .update(adminUsers)
            .set({ resetToken: null, resetTokenExpiry: null })
            .where(eq(adminUsers.id, id));
        // For SQLite, we'll assume it worked
        return true;
    }
    async updateLastLogin(id) {
        const result = await db
            .update(adminUsers)
            .set({ lastLogin: new Date() })
            .where(eq(adminUsers.id, id));
        // For SQLite, we'll assume it worked
        return true;
    }
}
export const storage = new DatabaseStorage();
