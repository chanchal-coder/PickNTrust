export { DatabaseStorage, storage } from './storage-fixed-api.js';
