import { sqliteDb } from './db.js';
export class DatabaseStorage {
    // FIXED: Products using unified_content with direct SQL and column aliases
    async getProducts() {
        try {
            console.log('🔍 DatabaseStorage: Getting products from unified_content with direct SQL...');
            console.log('📊 Database connection status:', sqliteDb ? 'Connected' : 'Not connected');
            const result = sqliteDb.prepare(`
        SELECT 
          id,
          title AS name,
          description,
          price,
          original_price AS originalPrice,
          currency,
          image_url AS imageUrl,
          affiliate_url AS affiliateUrl,
          category,
          rating,
          review_count AS reviewCount,
          discount,
          COALESCE(is_featured, 0) AS isFeatured,
          COALESCE(is_active, 1) AS isActive,
          created_at AS createdAt,
          updated_at AS updatedAt
        FROM unified_content
        WHERE 
          (status IN ('active','published') OR status IS NULL)
          AND (visibility IN ('public','visible') OR visibility IS NULL)
          AND (processing_status != 'archived' OR processing_status IS NULL)
        ORDER BY id DESC
      `).all();
            console.log(`✅ DatabaseStorage: Found ${result.length} products via unified_content`);
            if (result.length > 0) {
                console.log('📝 Sample product:', { id: result[0].id, name: result[0].name, price: result[0].price });
            }
            return result;
        }
        catch (error) {
            console.error('❌ DatabaseStorage: Error getting products:', error);
            return [];
        }
    }
    // Canva automation settings
    async getCanvaSettings() {
        try {
            // Ensure table exists
            sqliteDb.prepare(`
        CREATE TABLE IF NOT EXISTS canva_settings (
          id INTEGER PRIMARY KEY CHECK (id = 1),
          is_enabled INTEGER DEFAULT 0,
          api_key TEXT,
          api_secret TEXT,
          default_template_id TEXT,
          auto_generate_captions INTEGER DEFAULT 1,
          auto_generate_hashtags INTEGER DEFAULT 1,
          default_title TEXT,
          default_caption TEXT,
          default_hashtags TEXT,
          platforms TEXT,
          schedule_type TEXT DEFAULT 'immediate',
          schedule_delay_minutes INTEGER DEFAULT 0
        )
      `).run();
            const row = sqliteDb.prepare(`SELECT * FROM canva_settings WHERE id = 1`).get();
            if (!row)
                return null;
            return {
                isEnabled: !!row.is_enabled,
                apiKey: row.api_key ?? null,
                apiSecret: row.api_secret ?? null,
                defaultTemplateId: row.default_template_id ?? null,
                autoGenerateCaptions: !!row.auto_generate_captions,
                autoGenerateHashtags: !!row.auto_generate_hashtags,
                defaultTitle: row.default_title ?? null,
                defaultCaption: row.default_caption ?? null,
                defaultHashtags: row.default_hashtags ?? null,
                platforms: row.platforms ?? '[]',
                scheduleType: row.schedule_type ?? 'immediate',
                scheduleDelayMinutes: Number(row.schedule_delay_minutes ?? 0)
            };
        }
        catch (error) {
            console.error('❌ DatabaseStorage: Error getting Canva settings:', error);
            return null;
        }
    }
    async updateCanvaSettings(settings) {
        try {
            // Ensure table exists
            sqliteDb.prepare(`
        CREATE TABLE IF NOT EXISTS canva_settings (
          id INTEGER PRIMARY KEY CHECK (id = 1),
          is_enabled INTEGER DEFAULT 0,
          api_key TEXT,
          api_secret TEXT,
          default_template_id TEXT,
          auto_generate_captions INTEGER DEFAULT 1,
          auto_generate_hashtags INTEGER DEFAULT 1,
          default_title TEXT,
          default_caption TEXT,
          default_hashtags TEXT,
          platforms TEXT,
          schedule_type TEXT DEFAULT 'immediate',
          schedule_delay_minutes INTEGER DEFAULT 0
        )
      `).run();
            // Normalize values
            const payload = {
                id: 1,
                is_enabled: settings.isEnabled ? 1 : 0,
                api_key: settings.apiKey ?? null,
                api_secret: settings.apiSecret ?? null,
                default_template_id: settings.defaultTemplateId ?? null,
                auto_generate_captions: settings.autoGenerateCaptions === false ? 0 : 1,
                auto_generate_hashtags: settings.autoGenerateHashtags === false ? 0 : 1,
                default_title: settings.defaultTitle ?? null,
                default_caption: settings.defaultCaption ?? null,
                default_hashtags: settings.defaultHashtags ?? null,
                platforms: typeof settings.platforms === 'string' ? settings.platforms : JSON.stringify(settings.platforms ?? []),
                schedule_type: settings.scheduleType === 'scheduled' ? 'scheduled' : 'immediate',
                schedule_delay_minutes: Number(settings.scheduleDelayMinutes ?? 0)
            };
            // Upsert single settings row
            sqliteDb.prepare(`
        INSERT INTO canva_settings (
          id, is_enabled, api_key, api_secret, default_template_id,
          auto_generate_captions, auto_generate_hashtags,
          default_title, default_caption, default_hashtags,
          platforms, schedule_type, schedule_delay_minutes
        ) VALUES (
          @id, @is_enabled, @api_key, @api_secret, @default_template_id,
          @auto_generate_captions, @auto_generate_hashtags,
          @default_title, @default_caption, @default_hashtags,
          @platforms, @schedule_type, @schedule_delay_minutes
        )
        ON CONFLICT(id) DO UPDATE SET
          is_enabled = excluded.is_enabled,
          api_key = excluded.api_key,
          api_secret = excluded.api_secret,
          default_template_id = excluded.default_template_id,
          auto_generate_captions = excluded.auto_generate_captions,
          auto_generate_hashtags = excluded.auto_generate_hashtags,
          default_title = excluded.default_title,
          default_caption = excluded.default_caption,
          default_hashtags = excluded.default_hashtags,
          platforms = excluded.platforms,
          schedule_type = excluded.schedule_type,
          schedule_delay_minutes = excluded.schedule_delay_minutes
      `).run(payload);
            return await this.getCanvaSettings();
        }
        catch (error) {
            console.error('❌ DatabaseStorage: Error updating Canva settings:', error);
            throw error;
        }
    }
    async getFeaturedProducts() {
        try {
            const result = sqliteDb.prepare(`
        SELECT 
          id,
          title AS name,
          description,
          price,
          original_price AS originalPrice,
          currency,
          image_url AS imageUrl,
          affiliate_url AS affiliateUrl,
          category,
          rating,
          review_count AS reviewCount,
          discount,
          COALESCE(is_featured, 0) AS isFeatured,
          COALESCE(is_active, 1) AS isActive,
          created_at AS createdAt,
          updated_at AS updatedAt
        FROM unified_content
        WHERE 
          is_featured = 1
          AND (status IN ('active','published') OR status IS NULL)
          AND (visibility IN ('public','visible') OR visibility IS NULL)
          AND (processing_status != 'archived' OR processing_status IS NULL)
        ORDER BY id DESC
      `).all();
            return result;
        }
        catch (error) {
            console.error('❌ DatabaseStorage: Error getting featured products:', error);
            return [];
        }
    }
    async getProductsByCategory(category) {
        try {
            const result = sqliteDb.prepare(`
        SELECT 
          id,
          title AS name,
          description,
          price,
          original_price AS originalPrice,
          currency,
          image_url AS imageUrl,
          affiliate_url AS affiliateUrl,
          category,
          rating,
          review_count AS reviewCount,
          discount,
          COALESCE(is_featured, 0) AS isFeatured,
          COALESCE(is_active, 1) AS isActive,
          created_at AS createdAt,
          updated_at AS updatedAt
        FROM unified_content
        WHERE 
          category = ?
          AND (status IN ('active','published') OR status IS NULL)
          AND (visibility IN ('public','visible') OR visibility IS NULL)
          AND (processing_status != 'archived' OR processing_status IS NULL)
        ORDER BY id DESC
      `).all(category);
            return result;
        }
        catch (error) {
            console.error('❌ DatabaseStorage: Error getting products by category:', error);
            return [];
        }
    }
    async searchProducts(query) {
        try {
            const searchTerm = `%${query}%`;
            const result = sqliteDb.prepare(`
        SELECT 
          id,
          title AS name,
          description,
          price,
          original_price AS originalPrice,
          currency,
          image_url AS imageUrl,
          affiliate_url AS affiliateUrl,
          category,
          rating,
          review_count AS reviewCount,
          discount,
          COALESCE(is_featured, 0) AS isFeatured,
          COALESCE(is_active, 1) AS isActive,
          created_at AS createdAt,
          updated_at AS updatedAt
        FROM unified_content
        WHERE 
          (title LIKE ? OR description LIKE ?)
          AND (status IN ('active','published') OR status IS NULL)
          AND (visibility IN ('public','visible') OR visibility IS NULL)
          AND (processing_status != 'archived' OR processing_status IS NULL)
        ORDER BY id DESC
      `).all(searchTerm, searchTerm);
            return result;
        }
        catch (error) {
            console.error('❌ DatabaseStorage: Error searching products:', error);
            return [];
        }
    }
    async getProductById(id) {
        try {
            const result = sqliteDb.prepare(`
        SELECT 
          id,
          title AS name,
          description,
          price,
          original_price AS originalPrice,
          currency,
          image_url AS imageUrl,
          affiliate_url AS affiliateUrl,
          category,
          rating,
          review_count AS reviewCount,
          discount,
          COALESCE(is_featured, 0) AS isFeatured,
          COALESCE(is_active, 1) AS isActive,
          created_at AS createdAt,
          updated_at AS updatedAt
        FROM unified_content
        WHERE id = ?
      `).get(id);
            return result || null;
        }
        catch (error) {
            console.error('❌ DatabaseStorage: Error getting product by id:', error);
            return null;
        }
    }
    async createProduct(product) {
        try {
            const stmt = sqliteDb.prepare(`
        INSERT INTO unified_content (
          title, description, price, original_price, currency, image_url, affiliate_url, category, rating, review_count,
          content_type, status, visibility, processing_status, created_at, updated_at
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'product', 'active', 'public', 'completed', datetime('now'), datetime('now'))
      `);
            const result = stmt.run(product.name, product.description, product.price, product.originalPrice, product.currency || 'INR', product.imageUrl, product.affiliateUrl, product.category, product.rating, product.reviewCount);
            return { ...product, id: Number(result.lastInsertRowid) };
        }
        catch (error) {
            console.error('❌ DatabaseStorage: Error creating product:', error);
            throw error;
        }
    }
    // Other methods with direct SQL where needed
    async getCategories() {
        try {
            const result = sqliteDb.prepare('SELECT * FROM categories ORDER BY display_order ASC, name ASC').all();
            return result;
        }
        catch (error) {
            console.error('❌ DatabaseStorage: Error getting categories:', error);
            return [];
        }
    }
    async getBlogPosts() {
        try {
            const result = sqliteDb.prepare('SELECT * FROM blog_posts ORDER BY published_at DESC').all();
            return result;
        }
        catch (error) {
            console.error('❌ DatabaseStorage: Error getting blog posts:', error);
            return [];
        }
    }
    // Affiliate networks list
    async getAffiliateNetworks() {
        try {
            const rows = sqliteDb.prepare(`
        SELECT 
          id,
          name,
          slug,
          description,
          commission_rate AS commissionRate,
          tracking_params AS trackingParams,
          logo_url AS logoUrl,
          is_active AS isActive,
          join_url AS joinUrl
        FROM affiliate_networks
        ORDER BY id ASC
      `).all();
            return rows;
        }
        catch (error) {
            console.error('❌ DatabaseStorage: Error getting affiliate networks:', error);
            return [];
        }
    }
    // Admin Product Management (unified_content)
    async addProduct(productData) {
        try {
            const title = String(productData.name || '').trim();
            const description = String(productData.description || '').trim();
            const imageUrl = String(productData.imageUrl || '').trim();
            const affiliateUrl = String(productData.affiliateUrl || '').trim();
            const category = String(productData.category || '').trim();
            if (!title || !imageUrl || !affiliateUrl || !category) {
                throw new Error('Missing required fields: name, imageUrl, affiliateUrl, category');
            }
            const toNumber = (val) => {
                if (val === null || val === undefined || val === '')
                    return null;
                const num = typeof val === 'string' ? parseFloat(val.replace(/[^0-9.\-]/g, '')) : Number(val);
                return Number.isFinite(num) ? num : null;
            };
            const price = toNumber(productData.price);
            const originalPrice = toNumber(productData.originalPrice);
            const rating = toNumber(productData.rating);
            const reviewCount = toNumber(productData.reviewCount);
            const isFeatured = productData.isFeatured ? 1 : 0;
            const isService = productData.isService ? 1 : 0;
            // Persist selected pages as JSON string if provided and auto-tag common pages
            const displayPagesArr = Array.isArray(productData.displayPages)
                ? Array.from(new Set(productData.displayPages.map((p) => String(p).trim().toLowerCase()).filter(Boolean)))
                : [];
            // Auto-tag Services page when service flag is set
            if (isService && !displayPagesArr.includes('services')) {
                displayPagesArr.push('services');
            }
            // Auto-tag Apps page when AI App flag is set
            if (productData.isAIApp && !displayPagesArr.includes('apps')) {
                displayPagesArr.push('apps');
            }
            // Auto-tag Top Picks when featured is set
            if (isFeatured && !displayPagesArr.includes('top-picks')) {
                displayPagesArr.push('top-picks');
            }
            const displayPages = displayPagesArr.length > 0 ? JSON.stringify(displayPagesArr) : null;
            // Keep affiliateUrl as provided; Telegram bot handles link conversion
            // Map content type based on flags
            let contentType = 'product';
            if (productData.isService)
                contentType = 'service';
            else if (productData.isAIApp)
                contentType = 'app';
            const currency = (productData.currency || 'INR').toString();
            const payload = {
                title,
                description,
                price,
                original_price: originalPrice,
                currency,
                image_url: imageUrl,
                affiliate_url: affiliateUrl,
                category,
                rating,
                review_count: reviewCount,
                content_type: contentType,
                is_featured: isFeatured,
                is_service: isService,
                display_pages: displayPages,
            };
            const stmt = sqliteDb.prepare(`
        INSERT INTO unified_content (
          title, description, price, original_price, currency,
          image_url, affiliate_url, category, rating, review_count,
          content_type, status, visibility, processing_status,
          is_featured, is_service, display_pages, created_at, updated_at
        ) VALUES (
          @title, @description, @price, @original_price, @currency,
          @image_url, @affiliate_url, @category, @rating, @review_count,
          @content_type, 'active', 'public', 'completed',
          @is_featured, @is_service, @display_pages, datetime('now'), datetime('now')
        )
      `);
            const result = stmt.run(payload);
            const newId = Number(result.lastInsertRowid);
            const created = await this.getProductById(newId);
            if (!created)
                throw new Error('Failed to fetch created product');
            return created;
        }
        catch (error) {
            console.error('❌ DatabaseStorage: Error adding product:', error);
            throw error;
        }
    }
    async updateProduct(id, updates) {
        try {
            const setClauses = [];
            const params = { id };
            const mapField = (field, column, transform) => {
                const val = updates[field];
                if (val !== undefined) {
                    params[column] = transform ? transform(val) : val;
                    setClauses.push(`${column} = @${column}`);
                }
            };
            // No normalization on update; accept provided affiliateUrl
            const toNumber = (val) => {
                if (val === null || val === undefined || val === '')
                    return null;
                const num = typeof val === 'string' ? parseFloat(val.replace(/[^0-9.\-]/g, '')) : Number(val);
                return Number.isFinite(num) ? num : null;
            };
            mapField('name', 'title', (v) => String(v).trim());
            mapField('description', 'description', (v) => String(v).trim());
            mapField('price', 'price', toNumber);
            mapField('originalPrice', 'original_price', toNumber);
            mapField('currency', 'currency', (v) => String(v));
            mapField('imageUrl', 'image_url', (v) => String(v).trim());
            mapField('affiliateUrl', 'affiliate_url', (v) => String(v).trim());
            mapField('category', 'category', (v) => String(v).trim());
            mapField('rating', 'rating', toNumber);
            mapField('reviewCount', 'review_count', toNumber);
            if (updates.isFeatured !== undefined) {
                params['is_featured'] = updates.isFeatured ? 1 : 0;
                setClauses.push('is_featured = @is_featured');
            }
            if (updates.isService !== undefined) {
                params['is_service'] = updates.isService ? 1 : 0;
                setClauses.push('is_service = @is_service');
            }
            if (updates.displayPages !== undefined) {
                const arr = Array.isArray(updates.displayPages)
                    ? Array.from(new Set(updates.displayPages.map((p) => String(p).trim().toLowerCase()).filter(Boolean)))
                    : null;
                params['display_pages'] = arr ? JSON.stringify(arr) : null;
                setClauses.push('display_pages = @display_pages');
            }
            if (setClauses.length === 0) {
                // Nothing to update
                const current = await this.getProductById(id);
                return current;
            }
            const sqlStr = `UPDATE unified_content SET ${setClauses.join(', ')}, updated_at = datetime('now') WHERE id = @id`;
            sqliteDb.prepare(sqlStr).run(params);
            return await this.getProductById(id);
        }
        catch (error) {
            console.error('❌ DatabaseStorage: Error updating product:', error);
            return null;
        }
    }
    async deleteProduct(id) {
        try {
            const info = sqliteDb.prepare('DELETE FROM unified_content WHERE id = ?').run(id);
            return (info.changes || 0) > 0;
        }
        catch (error) {
            console.error('❌ DatabaseStorage: Error deleting product:', error);
            return false;
        }
    }
    // Video Content Management using direct SQLite
    async getVideoContent() {
        try {
            // Ensure table exists (idempotent)
            sqliteDb.prepare(`
        CREATE TABLE IF NOT EXISTS video_content (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          title TEXT NOT NULL,
          description TEXT,
          video_url TEXT NOT NULL,
          thumbnail_url TEXT,
          platform TEXT,
          category TEXT,
          tags TEXT,
          duration TEXT,
          has_timer INTEGER DEFAULT 0,
          timer_duration INTEGER,
          timer_start_time INTEGER,
          pages TEXT,
          show_on_homepage INTEGER DEFAULT 1,
          created_at INTEGER DEFAULT (strftime('%s','now')),
          updated_at INTEGER
        )
      `).run();
            const rows = sqliteDb.prepare(`
        SELECT 
          id,
          title,
          description,
          video_url AS videoUrl,
          thumbnail_url AS thumbnailUrl,
          platform,
          category,
          tags,
          duration,
          pages AS pagesRaw,
          COALESCE(show_on_homepage, 1) AS showOnHomepage,
          COALESCE(has_timer, 0) AS hasTimer,
          timer_duration AS timerDuration,
          timer_start_time * 1000 AS timerStartTime,
          created_at * 1000 AS createdAt,
          created_at * 1000 AS updatedAt
        FROM video_content
        ORDER BY created_at DESC, id DESC
      `).all();
            const normalized = rows.map((r) => {
                // Parse tags which may be JSON array or CSV string
                let tagsArr = null;
                if (Array.isArray(r.tags)) {
                    tagsArr = r.tags.map((t) => String(t));
                }
                else if (typeof r.tags === 'string' && r.tags.length) {
                    try {
                        const parsed = JSON.parse(r.tags);
                        if (Array.isArray(parsed)) {
                            tagsArr = parsed.map((t) => String(t));
                        }
                    }
                    catch {
                        tagsArr = r.tags.split(',').map((s) => s.trim()).filter(Boolean);
                    }
                }
                // Parse pages which may be JSON array or CSV string
                let pagesArr = [];
                if (Array.isArray(r.pagesRaw)) {
                    pagesArr = r.pagesRaw.map((p) => String(p).trim().toLowerCase()).filter(Boolean);
                }
                else if (typeof r.pagesRaw === 'string' && r.pagesRaw.length) {
                    try {
                        const parsed = JSON.parse(r.pagesRaw);
                        if (Array.isArray(parsed)) {
                            pagesArr = parsed.map((p) => String(p).trim().toLowerCase()).filter(Boolean);
                        }
                        else {
                            pagesArr = r.pagesRaw.split(',').map((s) => s.trim().toLowerCase()).filter(Boolean);
                        }
                    }
                    catch {
                        pagesArr = r.pagesRaw.split(',').map((s) => s.trim().toLowerCase()).filter(Boolean);
                    }
                }
                const out = {
                    id: r.id,
                    title: r.title,
                    description: r.description,
                    videoUrl: r.videoUrl,
                    thumbnailUrl: r.thumbnailUrl,
                    platform: r.platform,
                    category: r.category,
                    tags: tagsArr ?? r.tags ?? [],
                    duration: r.duration,
                    pages: pagesArr,
                    showOnHomepage: !!r.showOnHomepage,
                    hasTimer: r.hasTimer,
                    timerDuration: r.timerDuration,
                    timerStartTime: r.timerStartTime,
                    createdAt: r.createdAt,
                    updatedAt: r.updatedAt,
                };
                return out;
            });
            return normalized;
        }
        catch (error) {
            console.error('❌ DatabaseStorage: Error getting video content:', error);
            return [];
        }
    }
    async addVideoContent(videoData) {
        try {
            const DEFAULT_VIDEO_PAGES = [
                'home',
                'blog',
                'cue-picks',
                'global-picks',
                'loot-box',
                'live-deals',
                'travel-picks',
                'value-picks',
                'top-picks',
                'services',
                'apps',
                'prime-picks',
                'click-picks',
                'deals-hub',
                'trending'
            ];
            // Normalize inputs
            const hasTimer = !!videoData.hasTimer;
            const timerDuration = hasTimer && videoData.timerDuration ? parseInt(String(videoData.timerDuration)) : null;
            const nowSec = Math.floor(Date.now() / 1000);
            const timerStartTime = hasTimer ? nowSec : null;
            const tags = Array.isArray(videoData.tags) ? JSON.stringify(videoData.tags) : (typeof videoData.tags === 'string' ? videoData.tags : null);
            const pages = (() => {
                let arr = [];
                if (Array.isArray(videoData.pages)) {
                    arr = videoData.pages
                        .map((p) => String(p).trim().toLowerCase())
                        .filter(Boolean);
                }
                else if (typeof videoData.pages === 'string') {
                    arr = String(videoData.pages)
                        .split(',')
                        .map((s) => s.trim().toLowerCase())
                        .filter(Boolean);
                }
                if (!arr.length)
                    arr = DEFAULT_VIDEO_PAGES;
                return JSON.stringify(arr);
            })();
            const show_on_homepage = typeof videoData.showOnHomepage !== 'undefined' ? (videoData.showOnHomepage ? 1 : 0) : 1;
            const params = {
                title: String(videoData.title || '').trim(),
                description: videoData.description ?? null,
                video_url: String(videoData.videoUrl || videoData.video_url || '').trim(),
                thumbnail_url: videoData.thumbnailUrl ?? null,
                platform: videoData.platform ?? null,
                category: videoData.category ?? null,
                tags,
                duration: videoData.duration ?? null,
                has_timer: hasTimer ? 1 : 0,
                timer_duration: timerDuration,
                timer_start_time: timerStartTime,
                pages,
                show_on_homepage,
                created_at: nowSec
            };
            const insert = sqliteDb.prepare(`
        INSERT INTO video_content (
          title, description, video_url, thumbnail_url, platform, category, tags, duration,
          pages, show_on_homepage,
          has_timer, timer_duration, timer_start_time, created_at
        ) VALUES (
          @title, @description, @video_url, @thumbnail_url, @platform, @category, @tags, @duration,
          @pages, @show_on_homepage,
          @has_timer, @timer_duration, @timer_start_time, @created_at
        )
      `);
            const info = insert.run(params);
            const rowRaw = sqliteDb.prepare(`
        SELECT 
          id,
          title,
          description,
          video_url AS videoUrl,
          thumbnail_url AS thumbnailUrl,
          platform,
          category,
          tags,
          duration,
          pages AS pagesRaw,
          COALESCE(show_on_homepage, 1) AS showOnHomepage,
          COALESCE(has_timer, 0) AS hasTimer,
          timer_duration AS timerDuration,
          timer_start_time * 1000 AS timerStartTime,
          created_at * 1000 AS createdAt,
          created_at * 1000 AS updatedAt
        FROM video_content WHERE id = ?
      `).get(info.lastInsertRowid);
            // Normalize single row
            const r = rowRaw;
            let tagsArr = null;
            if (Array.isArray(r.tags)) {
                tagsArr = r.tags.map((t) => String(t));
            }
            else if (typeof r.tags === 'string' && r.tags.length) {
                try {
                    const parsed = JSON.parse(r.tags);
                    if (Array.isArray(parsed)) {
                        tagsArr = parsed.map((t) => String(t));
                    }
                }
                catch {
                    tagsArr = r.tags.split(',').map((s) => s.trim()).filter(Boolean);
                }
            }
            // Canonicalize page slugs with synonyms mapping
            const normalizeSlug = (val) => {
                const s = String(val || '')
                    .trim()
                    .toLowerCase()
                    .replace(/[^a-z0-9]+/g, '-')
                    .replace(/^-+|-+$/g, '');
                switch (s) {
                    case 'apps-ai-apps':
                    case 'apps-ai':
                    case 'ai-apps':
                        return 'apps';
                    case 'prime-picks':
                    case 'prime-pick':
                    case 'prime':
                    case 'primepicks':
                        return 'prime-picks';
                    case 'value-picks':
                    case 'value-pick':
                    case 'valuepicks':
                        return 'value-picks';
                    case 'top-picks':
                    case 'top-pick':
                    case 'toppicks':
                        return 'top-picks';
                    case 'travel-picks':
                    case 'travel-pick':
                        return 'travel-picks';
                    case 'click-picks':
                    case 'click-pick':
                    case 'clickpicks':
                        return 'click-picks';
                    case 'cue-picks':
                    case 'cue-pick':
                    case 'cuepicks':
                        return 'cue-picks';
                    case 'blogs':
                        return 'blog';
                    default:
                        return s;
                }
            };
            let pagesArr = [];
            if (Array.isArray(r.pagesRaw)) {
                pagesArr = r.pagesRaw.map((p) => normalizeSlug(p)).filter(Boolean);
            }
            else if (typeof r.pagesRaw === 'string' && r.pagesRaw.length) {
                try {
                    const parsed = JSON.parse(r.pagesRaw);
                    if (Array.isArray(parsed)) {
                        pagesArr = parsed.map((p) => normalizeSlug(p)).filter(Boolean);
                    }
                    else {
                        pagesArr = r.pagesRaw.split(',').map((s) => normalizeSlug(s)).filter(Boolean);
                    }
                }
                catch {
                    pagesArr = r.pagesRaw.split(',').map((s) => normalizeSlug(s)).filter(Boolean);
                }
            }
            return {
                id: r.id,
                title: r.title,
                description: r.description,
                videoUrl: r.videoUrl,
                thumbnailUrl: r.thumbnailUrl,
                platform: r.platform,
                category: r.category,
                tags: tagsArr ?? r.tags ?? [],
                duration: r.duration,
                pages: pagesArr,
                showOnHomepage: !!r.showOnHomepage,
                hasTimer: r.hasTimer,
                timerDuration: r.timerDuration,
                timerStartTime: r.timerStartTime,
                createdAt: r.createdAt,
                updatedAt: r.updatedAt,
            };
        }
        catch (error) {
            console.error('❌ DatabaseStorage: Error adding video content:', error);
            throw error;
        }
    }
    async updateVideoContent(id, updates) {
        try {
            const normalized = { ...updates };
            if (typeof normalized.hasTimer !== 'undefined') {
                normalized.has_timer = normalized.hasTimer ? 1 : 0;
                delete normalized.hasTimer;
            }
            if (typeof normalized.timerDuration !== 'undefined') {
                normalized.timer_duration = normalized.timerDuration != null ? parseInt(String(normalized.timerDuration)) : null;
                delete normalized.timerDuration;
            }
            if (Array.isArray(normalized.tags)) {
                normalized.tags = JSON.stringify(normalized.tags);
            }
            // Canonicalize pages on write
            const normalizeSlug = (val) => {
                const s = String(val || '')
                    .trim()
                    .toLowerCase()
                    .replace(/[^a-z0-9]+/g, '-')
                    .replace(/^-+|-+$/g, '');
                switch (s) {
                    case 'apps-ai-apps':
                    case 'apps-ai':
                    case 'ai-apps':
                        return 'apps';
                    case 'prime-picks':
                    case 'prime-pick':
                    case 'prime':
                    case 'primepicks':
                        return 'prime-picks';
                    case 'value-picks':
                    case 'value-pick':
                    case 'valuepicks':
                        return 'value-picks';
                    case 'top-picks':
                    case 'top-pick':
                    case 'toppicks':
                        return 'top-picks';
                    case 'travel-picks':
                    case 'travel-pick':
                        return 'travel-picks';
                    case 'click-picks':
                    case 'click-pick':
                    case 'clickpicks':
                        return 'click-picks';
                    case 'cue-picks':
                    case 'cue-pick':
                    case 'cuepicks':
                        return 'cue-picks';
                    case 'blogs':
                        return 'blog';
                    default:
                        return s;
                }
            };
            if (Array.isArray(normalized.pages)) {
                normalized.pages = JSON.stringify(normalized.pages.map((p) => normalizeSlug(p)).filter(Boolean));
            }
            else if (typeof normalized.pages === 'string') {
                const arr = String(normalized.pages)
                    .split(',')
                    .map((s) => normalizeSlug(s))
                    .filter(Boolean);
                normalized.pages = JSON.stringify(arr);
            }
            if (typeof normalized.showOnHomepage !== 'undefined') {
                normalized.show_on_homepage = normalized.showOnHomepage ? 1 : 0;
                delete normalized.showOnHomepage;
            }
            // Map camelCase to snake_case for known fields
            if (typeof normalized.videoUrl !== 'undefined') {
                normalized.video_url = normalized.videoUrl;
                delete normalized.videoUrl;
            }
            if (typeof normalized.thumbnailUrl !== 'undefined') {
                normalized.thumbnail_url = normalized.thumbnailUrl;
                delete normalized.thumbnailUrl;
            }
            const allowed = [
                'title', 'description', 'video_url', 'thumbnail_url', 'platform', 'category', 'tags', 'duration',
                'pages', 'show_on_homepage',
                'has_timer', 'timer_duration', 'timer_start_time'
            ];
            const setClauses = [];
            const params = { id };
            for (const key of allowed) {
                if (key in normalized) {
                    setClauses.push(`${key} = @${key}`);
                    params[key] = normalized[key];
                }
            }
            if (setClauses.length === 0) {
                // Nothing to update, return current row
                return sqliteDb.prepare(`
          SELECT id, title, description, video_url AS videoUrl, thumbnail_url AS thumbnailUrl, platform, category, tags, duration,
                 pages AS pagesRaw, COALESCE(show_on_homepage, 1) AS showOnHomepage,
                 COALESCE(has_timer, 0) AS hasTimer, timer_duration AS timerDuration,
                 timer_start_time * 1000 AS timerStartTime,
                 created_at * 1000 AS createdAt, created_at * 1000 AS updatedAt
          FROM video_content WHERE id = ?
        `).get(id) ?? null;
            }
            const sqlStr = `UPDATE video_content SET ${setClauses.join(', ')} WHERE id = @id`;
            sqliteDb.prepare(sqlStr).run(params);
            const updated = sqliteDb.prepare(`
        SELECT id, title, description, video_url AS videoUrl, thumbnail_url AS thumbnailUrl, platform, category, tags, duration,
               pages AS pagesRaw, COALESCE(show_on_homepage, 1) AS showOnHomepage,
               COALESCE(has_timer, 0) AS hasTimer, timer_duration AS timerDuration,
               timer_start_time * 1000 AS timerStartTime,
               created_at * 1000 AS createdAt, created_at * 1000 AS updatedAt
        FROM video_content WHERE id = ?
      `).get(id);
            if (!updated)
                return null;
            const r = updated;
            let tagsArr = null;
            if (Array.isArray(r.tags)) {
                tagsArr = r.tags.map((t) => String(t));
            }
            else if (typeof r.tags === 'string' && r.tags.length) {
                try {
                    const parsed = JSON.parse(r.tags);
                    if (Array.isArray(parsed)) {
                        tagsArr = parsed.map((t) => String(t));
                    }
                }
                catch {
                    tagsArr = r.tags.split(',').map((s) => s.trim()).filter(Boolean);
                }
            }
            // Canonicalize page slugs on read of updated row
            const normalizeSlugRead = (val) => {
                const s = String(val || '')
                    .trim()
                    .toLowerCase()
                    .replace(/[^a-z0-9]+/g, '-')
                    .replace(/^-+|-+$/g, '');
                switch (s) {
                    case 'apps-ai-apps':
                    case 'apps-ai':
                    case 'ai-apps':
                        return 'apps';
                    case 'prime-picks':
                    case 'prime-pick':
                    case 'prime':
                    case 'primepicks':
                        return 'prime-picks';
                    case 'value-picks':
                    case 'value-pick':
                    case 'valuepicks':
                        return 'value-picks';
                    case 'top-picks':
                    case 'top-pick':
                    case 'toppicks':
                        return 'top-picks';
                    case 'travel-picks':
                    case 'travel-pick':
                        return 'travel-picks';
                    case 'click-picks':
                    case 'click-pick':
                    case 'clickpicks':
                        return 'click-picks';
                    case 'cue-picks':
                    case 'cue-pick':
                    case 'cuepicks':
                        return 'cue-picks';
                    case 'blogs':
                        return 'blog';
                    default:
                        return s;
                }
            };
            let pagesArr = [];
            if (Array.isArray(r.pagesRaw)) {
                pagesArr = r.pagesRaw.map((p) => normalizeSlugRead(p)).filter(Boolean);
            }
            else if (typeof r.pagesRaw === 'string' && r.pagesRaw.length) {
                try {
                    const parsed = JSON.parse(r.pagesRaw);
                    if (Array.isArray(parsed)) {
                        pagesArr = parsed.map((p) => normalizeSlugRead(p)).filter(Boolean);
                    }
                    else {
                        pagesArr = r.pagesRaw.split(',').map((s) => normalizeSlugRead(s)).filter(Boolean);
                    }
                }
                catch {
                    pagesArr = r.pagesRaw.split(',').map((s) => normalizeSlugRead(s)).filter(Boolean);
                }
            }
            return {
                id: r.id,
                title: r.title,
                description: r.description,
                videoUrl: r.videoUrl,
                thumbnailUrl: r.thumbnailUrl,
                platform: r.platform,
                category: r.category,
                tags: tagsArr ?? r.tags ?? [],
                duration: r.duration,
                pages: pagesArr,
                showOnHomepage: !!r.showOnHomepage,
                hasTimer: r.hasTimer,
                timerDuration: r.timerDuration,
                timerStartTime: r.timerStartTime,
                createdAt: r.createdAt,
                updatedAt: r.updatedAt,
            };
        }
        catch (error) {
            console.error('❌ DatabaseStorage: Error updating video content:', error);
            return null;
        }
    }
    async deleteVideoContent(id) {
        try {
            const info = sqliteDb.prepare('DELETE FROM video_content WHERE id = ?').run(id);
            return (info.changes || 0) > 0;
        }
        catch (error) {
            console.error('❌ DatabaseStorage: Error deleting video content:', error);
            return false;
        }
    }
    async deleteAllVideoContent() {
        try {
            const info = sqliteDb.prepare('DELETE FROM video_content').run();
            return info.changes || 0;
        }
        catch (error) {
            console.error('❌ DatabaseStorage: Error bulk deleting video content:', error);
            return 0;
        }
    }
}
export const storage = new DatabaseStorage();
